# Reglas no negociables del proyecto

Este archivo se lee antes de editar cualquier archivo.

1. Las fuentes primarias locales están en `sources/`: el enunciado del proyecto es la fuente funcional principal; los materiales del curso determinan el alcance técnico. Los documentos Markdown no sustituyen los PDFs.
2. `sources/GUIDE_TO_DATA_STRUCTURES.pdf` solo autoriza los capítulos **1–7** para el código y las decisiones actuales. Árboles empiezan en el capítulo 8; los capítulos **8+ están fuera de alcance**.
3. No introducir estructuras o algoritmos posteriores sin una fuente posterior del curso: árboles/BST/AVL, heaps, hash/maps/sets, grafos, BFS/DFS, ordenamiento topológico y algoritmos formales de sorting.
4. Política académica: no usar bibliotecas que sustituyan la estructura que el estudiante debe implementar o analizar (por ejemplo `ArrayList`, `LinkedList`, `Stack`, `Queue`, `Deque`, `PriorityQueue`, `HashMap`, `HashSet`, `TreeMap`, `sort` o streams). No afirmar que el profesor las prohibió textualmente.
5. No prometer complejidades falsas. Toda operación relevante debe indicar condiciones e invariante. Buscar por ID en una lista es `O(n)`, no `O(1)`.
6. Toda API externa debe tener respaldo en documentación oficial del lenguaje elegido; todo diseño de estructura debe ser rastreable al material del curso.
7. Mantener cambios mínimos, explícitos y trazables. Antes de código nuevo, actualizar decisión, trazabilidad, prueba y complejidad correspondientes.
8. No crear interfaz gráfica. Por ahora se permiten consola y pruebas simples, cuando el lenguaje esté confirmado.
9. No tratar como hechos las decisiones marcadas `PENDING` o `PROVISIONAL`.
