# Residencias UNAL - Estructuras de Datos

Propuesta académica para registrar aspirantes a residencias universitarias, mantenerlos por prioridad socioeconómica y derivar quiénes obtienen cupo. `RESIDENCIAS_UNAL` es una decisión del equipo; los cuatro casos de `sources/PROBLEMAS_A_RESOLVER.pdf` son propuestas, no una selección obligatoria del profesor. El código incluido es trabajo adicional válido para Entrega 1, no un requisito de entrega.

## Estado

- Problema: `RESIDENCIAS_UNAL` confirmado.
- Lenguaje: Java, confirmado por decisión del proyecto; no es una exigencia del profesor.
- Estructura principal: ordered singly linked list implementada manualmente.
- Build validado: OpenJDK/Javac `1.8.0_504` local de validación.
- Pruebas: 14 escenarios, 133 verificaciones, 14 PASS y 0 FAIL.
- Entrega 1: el único elemento requerido del prototipo de software es este `README.md`; los archivos de código y las pruebas son opcionales.
- Fecha límite Moodle: **2026-10-04 23:59** (hora local de Moodle).
- Interfaz: consola mínima; no hay GUI.
- Integrantes: `[PENDIENTE: nombres reales]`.
- Número de equipo: `[PENDIENTE: número real]`.
- Repositorio remoto: `[PENDIENTE: URL]`.

## Decisiones principales

Los estudiantes se ordenan por puntaje socioeconómico ascendente y, en empate, por ID ascendente. Se conserva una sola lista canónica y un entero `availableSlots`; admitidos y no admitidos se derivan del prefijo de la lista. Buscar por ID es `O(n)` porque el alcance actual no autoriza hashing.

ID y puntaje usan `int`. Los IDs deben ser únicos, no se asumen contiguos y no se inventó un rango para el puntaje. El nombre debe contener texto y los cupos no pueden ser negativos.

## Estructura del proyecto

```text
.
|-- HANDOFF_INSTRUCTIONS.md # Pasos para crear y subir el repositorio real
|-- PRE_GIT_CHECKLIST.md    # Verificación previa al primer push
|-- PROJECT_RULES.md
|-- README.md
|-- docs/
|   |-- ARCHITECTURE.md
|   |-- COMPLEXITY_BASELINE.md
|   |-- DECISIONS.md
|   |-- DELIVERY1_REPORT_DRAFT.md
|   |-- IMPLEMENTATION_STATUS.md
|   |-- REQUIREMENTS_TRACEABILITY.md
|   `-- TEST_PLAN.md
|-- sources/                 # Índice de PDFs fuente excluidos deliberadamente
|-- src/
|   |-- ConsoleApp.java
|   |-- OrderedStudentList.java
|   |-- ResidenceSystem.java
|   `-- Student.java
`-- test/
    `-- ResidenceSystemTest.java
```

## Requisitos de ejecución

Se necesita un JDK con `javac` y `java` capaz de compilar código Java convencional compatible con Java 8. Esta compatibilidad es una decisión práctica del MVP, no un requisito académico del curso. No se usan Maven, Gradle, JUnit ni dependencias externas.

## Qué no se debe subir

No agregues archivos compilados (`out/`, `*.class`), configuraciones locales del editor, cachés, archivos temporales, ZIPs ni los PDFs de `sources/`. Este paquete conserva solamente `sources/README.md`, que documenta los nombres y el propósito de esas fuentes; los PDFs se excluyeron deliberadamente por ser materiales locales de consulta y no parte del repositorio académico.

Antes de crear el repositorio remoto, completa los tres placeholders de estado (nombre del único integrante, número de equipo y URL del repositorio) y sigue [HANDOFF_INSTRUCTIONS.md](HANDOFF_INSTRUCTIONS.md).

## Compilar

Desde la raíz del proyecto, en PowerShell:

```powershell
New-Item -ItemType Directory -Force -Path out | Out-Null
javac -Xlint:all -d out src\Student.java src\OrderedStudentList.java src\ResidenceSystem.java src\ConsoleApp.java test\ResidenceSystemTest.java
```

## Ejecutar pruebas

```powershell
java -cp out ResidenceSystemTest
```

Resultado validado:

```text
Scenarios: 14
PASS: 14
FAIL: 0
Assertions: 133
```

## Ejecutar la consola

```powershell
java -cp out ConsoleApp
```

La consola permite registrar, consultar, listar, modificar puntajes, eliminar, establecer cupos y mostrar admitidos/no admitidos.

## Complejidades principales

| Operación | Peor caso |
|---|---:|
| Registrar con inserción ordenada | O(n) |
| Buscar por ID | O(n) |
| Eliminar por ID | O(n) |
| Modificar puntaje y reubicar | O(n) |
| Listar todos | O(n) |
| Listar admitidos | O(min(k,n)) |
| Listar no admitidos | O(n) |
| Establecer cupos | O(1) |
| `size` / `isEmpty` | O(1) |

Dos recorridos lineales sucesivos siguen siendo `O(n)`. Los arrays devueltos por los listados requieren espacio proporcional a su resultado.

## Restricciones académicas

- Guide limitado estrictamente a capítulos 1-7.
- Sin árboles, AVL, heaps, hashing, maps, sets, grafos ni sorting formal.
- Sin `ArrayList`, `LinkedList`, `PriorityQueue`, `HashMap`, `HashSet`, `Collections.sort`, `Arrays.sort`, streams o frameworks.
- El orden se conserva durante la inserción; nunca se ejecuta sorting global posterior.
- Estas restricciones son política del proyecto para preservar el aprendizaje evaluable; no se atribuyen como prohibición textual del profesor.

## Fuentes y documentación

- Auditoría primaria: [docs/SOURCE_AUDIT.md](docs/SOURCE_AUDIT.md).
- Decisiones: [docs/DECISIONS.md](docs/DECISIONS.md).
- Trazabilidad: [docs/REQUIREMENTS_TRACEABILITY.md](docs/REQUIREMENTS_TRACEABILITY.md).
- Referencias oficiales Java: [docs/references/JAVA_OFFICIAL_REFERENCES.md](docs/references/JAVA_OFFICIAL_REFERENCES.md).

## Siguiente paso de Entrega 1

Completar nombre del único integrante, número de equipo y URL del repositorio; sustituir los placeholders y regenerar el PDF definitivo. Subir una única entrega grupal antes de las **23:59** del 2026-10-04 (hora local de Moodle). La cantidad de commits por integrante no se evalúa en esta entrega.

La aclaración oficial posterior está registrada en [docs/MOODLE_CLARIFICATION.md](docs/MOODLE_CLARIFICATION.md).
