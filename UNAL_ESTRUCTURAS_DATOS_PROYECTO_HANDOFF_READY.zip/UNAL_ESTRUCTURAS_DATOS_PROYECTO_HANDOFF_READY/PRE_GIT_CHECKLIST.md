# Checklist antes del primer push

Marca cada punto solo cuando esté comprobado.

- [ ] El nombre real del único integrante sustituyó el placeholder en `README.md` y en cualquier documento que corresponda.
- [ ] El número real de equipo sustituyó el placeholder donde corresponda.
- [ ] La URL remota real fue creada o está confirmada; no se inventó una URL.
- [ ] Se revisó `README.md`, incluidos los comandos de compilación, pruebas y consola.
- [ ] El paquete contiene `src/`, `test/`, `docs/` y `sources/README.md`.
- [ ] No existe ningún archivo `sources/*.pdf` dentro de la carpeta de trabajo.
- [ ] No existen `out/`, `bin/`, `build/`, `target/`, archivos `.class`, cachés ni temporales pendientes de agregar.
- [ ] `git status` fue revisado antes del commit y solo muestra archivos intencionales.
- [ ] El primer commit fue creado con la identidad real del integrante; no se inventaron autores ni commits.
- [ ] Tras el commit, `git status` está limpio.
- [ ] Tras el push, el repositorio remoto fue revisado y no contiene PDFs fuente ni binarios.
