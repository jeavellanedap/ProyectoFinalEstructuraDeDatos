# Pendientes

## Completado

- [x] SOURCE_AUDIT con páginas exactas.
- [x] Confirmar `RESIDENCIAS_UNAL` y Java.
- [x] Congelar requisitos, arquitectura, invariante y complejidades.
- [x] Implementar ordered singly linked list y MVP adicional opcional.
- [x] Ejecutar 14 escenarios y 133 verificaciones como validación adicional.
- [x] Preparar README y borrador técnico de Entrega 1.
- [x] Sincronizar la aclaración oficial de Moodle y deadline `2026-10-04 23:59`.

## Requiere intervención humana

- [ ] Registrar nombre del único integrante y número de equipo.
- [ ] Añadir la URL del repositorio.
- [ ] Sustituir los placeholders y regenerar/revisar el PDF definitivo de máximo cuatro páginas.
- [ ] Comprobar el enlace y realizar una única entrega grupal antes de `2026-10-04 23:59` (hora local de Moodle).

No son pendientes/bloqueos de Entrega 1: código inicial, pruebas, nuevas funcionalidades o una cantidad mínima de commits.
