/** Executable test harness with no external dependencies. */
public final class ResidenceSystemTest {
    private static int scenariosRun;
    private static int scenariosPassed;
    private static int assertions;

    private ResidenceSystemTest() {
    }

    public static void main(String[] args) {
        for (int id = 1; id <= 14; id++) {
            runScenario(id);
        }

        int failed = scenariosRun - scenariosPassed;
        System.out.println();
        System.out.println("Scenarios: " + scenariosRun);
        System.out.println("PASS: " + scenariosPassed);
        System.out.println("FAIL: " + failed);
        System.out.println("Assertions: " + assertions);

        if (failed > 0) {
            throw new AssertionError(failed + " scenario(s) failed.");
        }
    }

    private static void runScenario(int id) {
        scenariosRun++;
        String name = scenarioName(id);
        try {
            switch (id) {
                case 1:
                    testInitiallyEmpty();
                    break;
                case 2:
                    testFirstAndHeadInsertion();
                    break;
                case 3:
                    testMiddleAndEndInsertion();
                    break;
                case 4:
                    testScoreTies();
                    break;
                case 5:
                    testDuplicateId();
                    break;
                case 6:
                    testSearchById();
                    break;
                case 7:
                    testRemovalAndReinsertion();
                    break;
                case 8:
                    testScoreMovesBothDirections();
                    break;
                case 9:
                    testUpdateCreatesTie();
                    break;
                case 10:
                    testMultipleUpdatesPreserveOrder();
                    break;
                case 11:
                    testSlotBoundaries();
                    break;
                case 12:
                    testDerivedAcceptedAndRejected();
                    break;
                case 13:
                    testMixedOperations();
                    break;
                case 14:
                    testInvalidInputs();
                    break;
                default:
                    throw new AssertionError("Unknown scenario: " + id);
            }
            scenariosPassed++;
            System.out.println("PASS T-" + twoDigits(id) + " " + name);
        } catch (Throwable error) {
            System.out.println("FAIL T-" + twoDigits(id) + " " + name
                    + ": " + error.getMessage());
        }
    }

    private static void testInitiallyEmpty() {
        ResidenceSystem system = new ResidenceSystem();
        check(system.isEmpty(), "New system must be empty.");
        check(system.size() == 0, "Initial size must be zero.");
        check(system.findStudentById(1) == null, "Unknown ID must return null.");
        check(!system.removeStudent(1), "Removing unknown ID must return false.");
        check(!system.updateStudentScore(1, 10), "Updating unknown ID must return false.");
        check(system.getStudentsOrdered().length == 0, "Ordered list must be empty.");
        check(system.getAcceptedStudents().length == 0, "Accepted list must be empty.");
        check(system.getRejectedStudents().length == 0, "Rejected list must be empty.");
        check(system.hasValidInvariant(), "Empty invariant must be valid.");
    }

    private static void testFirstAndHeadInsertion() {
        ResidenceSystem system = new ResidenceSystem();
        check(system.registerStudent(2, "Dos", 20), "First registration must succeed.");
        check(system.registerStudent(1, "Uno", 10), "Head registration must succeed.");
        checkIds(system.getStudentsOrdered(), new int[] {1, 2});
        check(system.size() == 2, "Size must track insertions.");
        check(system.hasValidInvariant(), "Invariant after head insertion.");
    }

    private static void testMiddleAndEndInsertion() {
        ResidenceSystem system = new ResidenceSystem();
        system.registerStudent(10, "Diez", 10);
        system.registerStudent(30, "Treinta", 30);
        system.registerStudent(20, "Veinte", 20);
        system.registerStudent(40, "Cuarenta", 40);
        checkIds(system.getStudentsOrdered(), new int[] {10, 20, 30, 40});
        check(system.hasValidInvariant(), "Invariant after middle/end insertion.");
    }

    private static void testScoreTies() {
        ResidenceSystem system = new ResidenceSystem();
        system.registerStudent(30, "Treinta", 10);
        system.registerStudent(10, "Diez", 10);
        system.registerStudent(20, "Veinte", 10);
        checkIds(system.getStudentsOrdered(), new int[] {10, 20, 30});
        check(system.hasValidInvariant(), "Tie order must satisfy invariant.");
    }

    private static void testDuplicateId() {
        ResidenceSystem system = new ResidenceSystem();
        check(system.registerStudent(7, "Original", 30), "Original must register.");
        check(!system.registerStudent(7, "Duplicado", 1), "Duplicate ID must be rejected.");
        check(system.size() == 1, "Duplicate must not change size.");
        check("Original".equals(system.findStudentById(7).getFullName()),
                "Duplicate must not replace original.");
        check(system.hasValidInvariant(), "Duplicate rejection must preserve invariant.");
    }

    private static void testSearchById() {
        ResidenceSystem system = sampleSystem();
        Student student = system.findStudentById(3);
        check(student != null, "Existing ID must be found.");
        check(student.getSocioeconomicScore() == 30, "Found data must match.");
        check(system.findStudentById(99) == null, "Missing ID must return null.");
    }

    private static void testRemovalAndReinsertion() {
        ResidenceSystem system = systemWithFourStudents();
        check(system.removeStudent(1), "Head removal must succeed.");
        checkIds(system.getStudentsOrdered(), new int[] {2, 3, 4});
        check(system.removeStudent(3), "Middle removal must succeed.");
        checkIds(system.getStudentsOrdered(), new int[] {2, 4});
        check(system.removeStudent(4), "Last removal must succeed.");
        checkIds(system.getStudentsOrdered(), new int[] {2});
        check(!system.removeStudent(99), "Missing removal must fail.");
        check(system.removeStudent(2), "Final node removal must succeed.");
        check(system.isEmpty(), "System must become empty.");
        check(system.registerStudent(3, "Tres otra vez", 15), "Reinsertion must succeed.");
        checkIds(system.getStudentsOrdered(), new int[] {3});
        check(system.hasValidInvariant(), "Removal/reinsertion invariant.");
    }

    private static void testScoreMovesBothDirections() {
        ResidenceSystem system = sampleSystem();
        check(system.updateStudentScore(1, 40), "Score increase must update.");
        checkIds(system.getStudentsOrdered(), new int[] {2, 3, 1});
        check(system.hasValidInvariant(), "Invariant after move toward end.");
        check(system.updateStudentScore(1, 5), "Score decrease must update.");
        checkIds(system.getStudentsOrdered(), new int[] {1, 2, 3});
        check(system.hasValidInvariant(), "Invariant after move toward head.");
    }

    private static void testUpdateCreatesTie() {
        ResidenceSystem system = new ResidenceSystem();
        system.registerStudent(3, "Tres", 10);
        system.registerStudent(1, "Uno", 20);
        system.registerStudent(2, "Dos", 30);
        check(system.updateStudentScore(2, 20), "Update creating tie must succeed.");
        checkIds(system.getStudentsOrdered(), new int[] {3, 1, 2});
        check(system.hasValidInvariant(), "Tie update invariant.");
    }

    private static void testMultipleUpdatesPreserveOrder() {
        ResidenceSystem system = systemWithFourStudents();
        check(system.updateStudentScore(4, 5), "Move 4 to head.");
        check(system.hasValidInvariant(), "Invariant after first update.");
        check(system.updateStudentScore(2, 35), "Move 2 near end.");
        check(system.hasValidInvariant(), "Invariant after second update.");
        check(system.updateStudentScore(1, 35), "Create tie at 35.");
        check(system.hasValidInvariant(), "Invariant after third update.");
        checkIds(system.getStudentsOrdered(), new int[] {4, 3, 1, 2});
        check(!system.updateStudentScore(99, 0), "Missing update must fail.");
    }

    private static void testSlotBoundaries() {
        ResidenceSystem system = sampleSystem();
        system.setAvailableSlots(0);
        check(system.getAcceptedStudents().length == 0, "Zero slots accepts none.");
        check(system.getRejectedStudents().length == 3, "Zero slots rejects all.");
        system.setAvailableSlots(2);
        checkIds(system.getAcceptedStudents(), new int[] {1, 2});
        checkIds(system.getRejectedStudents(), new int[] {3});
        system.setAvailableSlots(3);
        check(system.getAcceptedStudents().length == 3, "Equal slots accepts all.");
        check(system.getRejectedStudents().length == 0, "Equal slots rejects none.");
        system.setAvailableSlots(8);
        check(system.getAcceptedStudents().length == 3, "Extra slots accepts all existing.");
        check(system.getRejectedStudents().length == 0, "Extra slots rejects none.");
    }

    private static void testDerivedAcceptedAndRejected() {
        ResidenceSystem system = systemWithFourStudents();
        system.setAvailableSlots(2);
        checkIds(system.getAcceptedStudents(), new int[] {1, 2});
        checkIds(system.getRejectedStudents(), new int[] {3, 4});
        system.setAvailableSlots(1);
        checkIds(system.getAcceptedStudents(), new int[] {1});
        checkIds(system.getRejectedStudents(), new int[] {2, 3, 4});
        check(system.removeStudent(1), "Removing accepted student must succeed.");
        checkIds(system.getAcceptedStudents(), new int[] {2});
        checkIds(system.getRejectedStudents(), new int[] {3, 4});
        check(system.size() == system.getAcceptedStudents().length
                + system.getRejectedStudents().length,
                "Derived partitions must cover every student.");
    }

    private static void testMixedOperations() {
        ResidenceSystem system = new ResidenceSystem();
        system.setAvailableSlots(2);
        system.registerStudent(8, "Ocho", 80);
        system.registerStudent(2, "Dos", 20);
        system.registerStudent(5, "Cinco", 50);
        check(system.hasValidInvariant(), "Invariant after mixed inserts.");
        system.updateStudentScore(8, 10);
        check(system.hasValidInvariant(), "Invariant after mixed update.");
        system.removeStudent(5);
        check(system.hasValidInvariant(), "Invariant after mixed remove.");
        system.registerStudent(5, "Cinco", 15);
        check(system.hasValidInvariant(), "Invariant after mixed reinsertion.");
        checkIds(system.getStudentsOrdered(), new int[] {8, 5, 2});
        checkIds(system.getAcceptedStudents(), new int[] {8, 5});
        checkIds(system.getRejectedStudents(), new int[] {2});
        check(system.size() == 3, "Mixed sequence size.");
    }

    private static void testInvalidInputs() {
        ResidenceSystem system = new ResidenceSystem();
        boolean nullNameRejected = false;
        try {
            system.registerStudent(1, null, 10);
        } catch (IllegalArgumentException expected) {
            nullNameRejected = true;
        }
        check(nullNameRejected, "Null name must be rejected.");

        boolean emptyNameRejected = false;
        try {
            system.registerStudent(1, "   ", 10);
        } catch (IllegalArgumentException expected) {
            emptyNameRejected = true;
        }
        check(emptyNameRejected, "Empty name must be rejected.");

        boolean negativeSlotsRejected = false;
        try {
            system.setAvailableSlots(-1);
        } catch (IllegalArgumentException expected) {
            negativeSlotsRejected = true;
        }
        check(negativeSlotsRejected, "Negative slots must be rejected.");
        check(system.registerStudent(-5, "ID no contiguo", -10),
                "No undocumented ID/score range must be invented.");
        check(system.hasValidInvariant(), "Invariant after valid negative integer values.");
    }

    private static ResidenceSystem sampleSystem() {
        ResidenceSystem system = new ResidenceSystem();
        system.registerStudent(1, "Uno", 10);
        system.registerStudent(2, "Dos", 20);
        system.registerStudent(3, "Tres", 30);
        return system;
    }

    private static ResidenceSystem systemWithFourStudents() {
        ResidenceSystem system = sampleSystem();
        system.registerStudent(4, "Cuatro", 40);
        return system;
    }

    private static void checkIds(Student[] students, int[] expectedIds) {
        check(students.length == expectedIds.length,
                "Expected " + expectedIds.length + " students but got " + students.length + ".");
        for (int i = 0; i < expectedIds.length; i++) {
            check(students[i].getId() == expectedIds[i],
                    "Position " + i + ": expected ID " + expectedIds[i]
                            + " but got " + students[i].getId() + ".");
        }
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static String scenarioName(int id) {
        String[] names = {
            "",
            "initially empty",
            "first and head insertion",
            "middle and end insertion",
            "score ties",
            "duplicate ID",
            "search by ID",
            "removal and reinsertion",
            "score moves both directions",
            "update creates tie",
            "multiple updates preserve order",
            "slot boundaries",
            "derived accepted and rejected",
            "mixed operations",
            "invalid inputs"
        };
        return names[id];
    }

    private static String twoDigits(int value) {
        return value < 10 ? "0" + value : String.valueOf(value);
    }
}
