# Pruebas

`ResidenceSystemTest.java` es un harness ejecutable sin dependencias externas. Cubre los 14 escenarios de `docs/TEST_PLAN.md` y falla mediante `AssertionError` si una verificación no se cumple.

```powershell
javac -Xlint:all -d out src\Student.java src\OrderedStudentList.java src\ResidenceSystem.java src\ConsoleApp.java test\ResidenceSystemTest.java
java -cp out ResidenceSystemTest
```

Última validación: 14 escenarios PASS, 0 FAIL y 133 verificaciones.
