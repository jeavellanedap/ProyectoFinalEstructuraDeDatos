# Handoff: crear y subir el repositorio

Sigue estos pasos desde la carpeta descomprimida. No inventes el nombre del integrante, número de equipo, URL remota ni identidad Git: usa los datos reales.

1. Descomprime `UNAL_ESTRUCTURAS_DATOS_PROYECTO_HANDOFF.zip` en una ubicación de trabajo.
2. Abre una terminal en la carpeta que contiene `README.md`.
3. Revisa `README.md` y completa los placeholders pendientes: nombre del único integrante, número de equipo y URL del repositorio. Revisa también `PRE_GIT_CHECKLIST.md`.
4. Confirma que existen `src/`, `test/`, `docs/` y `sources/README.md`.
5. Confirma que no hay archivos `sources/*.pdf`, carpetas `out/`, archivos `.class` ni carpeta `.git/` heredada.
6. Si no existe un repositorio Git, inicialízalo:

   ```powershell
   git init
   ```

7. Agrega los archivos y revisa exactamente qué entrará al primer commit:

   ```powershell
   git add .
   git status
   ```

   Si aparece un PDF fuente, un binario o una carpeta de salida, retíralo antes de continuar. Los PDFs fuente no deben estar presentes ni versionados.

8. Configura tu identidad Git si todavía no está configurada y realiza un commit **real**, con tu propia identidad y un mensaje que describa el estado inicial. Por ejemplo:

   ```powershell
   git config user.name "Tu nombre real"
   git config user.email "tu-correo-real@example.com"
   git commit -m "Inicializa proyecto Residencias UNAL"
   ```

9. Crea un repositorio vacío en GitHub o GitLab, sin inventar ni reutilizar una URL. Después conecta la URL que acabas de crear:

   ```powershell
   git branch -M main
   git remote add origin <URL_REMOTA_REAL>
   git push -u origin main
   ```

10. Abre el repositorio remoto y verifica que están `README.md`, `src/`, `test/` y `docs/`, y que no están `sources/*.pdf`, `out/` ni archivos `.class`.

Para compilar, ejecutar pruebas o iniciar la consola, usa los comandos de `README.md`. No avances esta base hacia Entrega 2 durante este handoff.
