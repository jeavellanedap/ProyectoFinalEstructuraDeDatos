# Hoja de ruta

1. [x] Auditar fuentes primarias y límite académico.
2. [x] Confirmar Residencias UNAL y Java.
3. [x] Congelar requisitos, decisiones menores, arquitectura, pruebas y complejidades.
4. [x] Preparar el `README.md` requerido para Entrega 1.
5. [x] Implementar y probar un MVP adicional opcional con ordered singly linked list manual.
6. [x] Registrar la aclaración oficial de Moodle y el deadline `2026-10-04 23:59`.
7. [ ] Completar nombre del único integrante, número de equipo y URL del repositorio.
8. [ ] Sustituir placeholders, maquetar/revisar y regenerar el PDF final de máximo cuatro páginas.
9. [ ] Subir una única entrega grupal antes de la hora límite de Moodle.

No iniciar Entrega 2, Entrega 3, estructuras posteriores ni una nueva fase técnica. Moodle indica que E2 y E3 serán implementaciones diferentes; su alcance aún no se diseña.
