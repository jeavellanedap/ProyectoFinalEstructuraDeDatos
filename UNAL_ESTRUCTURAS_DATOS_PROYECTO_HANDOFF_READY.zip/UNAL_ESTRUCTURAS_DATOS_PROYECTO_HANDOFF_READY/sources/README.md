# Índice de fuentes primarias excluidas

Los seis PDFs usados durante la auditoría documental **no se incluyen en este paquete de handoff**. Son materiales locales de consulta, no archivos que deban versionarse. Esta carpeta conserva solo este índice para documentar sus nombres, propósito y alcance. La regla `/.gitignore` (`/sources/*.pdf`) evita añadirlos por error si se copian localmente en el futuro.

| Nombre local | Nombre original | Propósito | Alcance autorizado | Tipo |
|---|---|---|---|---|
| `PROBLEMAS_A_RESOLVER.pdf` | `PROBLEMAS A RESOLVER.pdf` | Cuatro ideas/propuestas de problema. | Si el equipo confirma una, aporta el alcance funcional de esa propuesta; Moodle aclara que no obliga a seleccionar ni resolver una. | Propuestas del curso |
| `ESPECIFICACION_ENTREGA1_PROYECTO.pdf` | `Especificación_Entrega1_Proyecto.pdf` | Reglas y entregables de Entrega 1. | Evidencia de requisitos de entrega y lenguaje, si la fuente lo establece. | Normativa del proyecto |
| `GUIDE_TO_DATA_STRUCTURES.pdf` | `Guide to Data Structures_A Concise Introduction Using Java.pdf` | Referencia académica principal. | **Únicamente capítulos 1–7 para código y decisiones actuales. Capítulos 8+ están fuera de alcance.** | Académica |
| `ARRAYS_AND_LINKED_LISTS_RHODES.pdf` | `Arrays and Linked Lists - Neil Rhodes-UCSD.pdf` | Arrays y listas enlazadas. | Apoyo académico dentro del alcance vigente. | Académica |
| `STACKS_AND_QUEUES_RHODES.pdf` | `05_2_stacks_and_queues.pdf` | Pilas y colas. | Apoyo académico dentro del alcance vigente. | Académica |
| `DYNAMIC_ARRAYS_AMORTIZED_ANALYSIS_RHODES.pdf` | `05_4_dynamic_arrays_and_amortized_analysis.pdf` | Arreglos dinámicos y análisis amortizado. | Apoyo académico dentro del alcance vigente. | Académica |

Regla repetida para la auditoría: `GUIDE_TO_DATA_STRUCTURES.pdf` permite usar **solo los capítulos 1–7**. Los capítulos **8 y posteriores** quedan fuera de alcance para todo código y toda decisión actual.

El índice duplicado para navegación desde `docs/` está en `../docs/references/SOURCES_INDEX.md`.
