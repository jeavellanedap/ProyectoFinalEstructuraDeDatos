# Plan de pruebas - Residencias UNAL

Las pruebas serán un harness Java sin dependencias externas. Cada prueba contiene verificaciones que lanzan `AssertionError` ante una diferencia; imprimir datos no cuenta como validación.

| ID | Escenario | Verificaciones principales | Requisitos |
|---|---|---|---|
| T-01 | Lista inicialmente vacía | `size == 0`, `isEmpty`, búsqueda/eliminación/actualización inexistentes, listados vacíos, invariante | R-04, R-09, R-10, D-02 |
| T-02 | Primera inserción e inserción al inicio | Orden, tamaño, búsqueda e invariante | R-01, R-05, R-11 |
| T-03 | Inserción al medio y al final | Orden completo e invariante | R-01, R-05, R-11 |
| T-04 | Puntajes empatados | Desempate por ID ascendente | R-01, R-05, R-11, D-01 |
| T-05 | ID duplicado | Rechazo sin cambio de tamaño/orden | R-02 |
| T-06 | Búsqueda por ID | Existente e inexistente | R-04 |
| T-07 | Eliminación | Head, nodo intermedio, último, inexistente y reinserción | R-10 |
| T-08 | Puntaje hacia arriba y abajo | Reposicionamiento correcto | R-09 |
| T-09 | Cambio que produce empate | Desempate por ID conservado | R-09, D-01 |
| T-10 | Múltiples modificaciones | Orden e invariante tras cada operación | R-05, R-09, R-11 |
| T-11 | Cupos | Cero, menos, igual y más cupos que estudiantes | R-03, R-06, R-07, R-08 |
| T-12 | Admitidos/no admitidos | Partición completa, sin duplicados y reacción a cambio de cupos/eliminación | R-06, R-07, R-08 |
| T-13 | Secuencia mixta | Registros, updates, removes, reinserción, tamaño e invariante | Todos |
| T-14 | Entradas inválidas | Nombre nulo/vacío y cupos negativos; puntajes enteros sin rango inventado | R-01, R-03 |

## Criterio de aprobación

- compilación completa sin errores;
- cero pruebas fallidas;
- invariante válido después de toda operación mutante;
- ninguna colección estándar sustituye la lista manual;
- las complejidades documentadas coinciden con recorridos reales.

## Resultado ejecutado

| Métrica | Resultado |
|---|---:|
| Escenarios | 14 |
| PASS | 14 |
| FAIL | 0 |
| Verificaciones | 133 |

Compilación con `javac -Xlint:all`: exit code 0 y sin advertencias. Todos los escenarios T-01 a T-14 pasaron.
