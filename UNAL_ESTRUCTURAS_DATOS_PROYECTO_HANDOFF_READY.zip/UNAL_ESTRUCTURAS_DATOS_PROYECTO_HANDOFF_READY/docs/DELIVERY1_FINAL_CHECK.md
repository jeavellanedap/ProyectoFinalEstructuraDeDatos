# DELIVERY1_FINAL_CHECK

Fecha de cierre documental: 2026-10-04

`DELIVERY1_CLOSEOUT_RESULT = PARTIAL`

## Validacion realizada

| Requisito de Entrega 1 | Estado | Evidencia / accion pendiente |
|---|---|---|
| Reporte tecnico PDF de maximo cuatro paginas | PASS | PDF de revision creado y validado visualmente: 2 paginas. |
| Titulo e integrantes | PARTIAL | Titulo incluido; faltan datos reales en `[[INTEGRANTES]]`. |
| Descripcion clara del problema | PASS | Seccion "Problema y proposito". |
| Diagrama con actores, componentes y relaciones | PASS | Diagrama estatico legible incluido. |
| Estructura y justificacion | PASS | Lista enlazada simple ordenada, invariante y trade-off documentados. |
| Boceto MVP / requisitos clave | PASS | Seccion "MVP y flujo de asignacion". |
| Flujo y uso de la estructura | PASS | Flujo estatico y derivacion de admitidos/no admitidos. |
| Enlace directo al repositorio al final | PARTIAL | Marcado como `[[REPO_URL]]`; debe sustituirse por URL real. |
| README como prototipo requerido | PASS | `README.md` está presente. Código, archivos iniciales y pruebas son opcionales para Entrega 1. |
| Datos humanos del README | PARTIAL | Faltan nombre del único integrante y URL del repositorio. |
| Repositorio compartido | PARTIAL | Falta `[[REPO_URL]]` real para comprobar el enlace directo. No existe un requisito de commits mínimos en esta entrega. |
| Cantidad de commits por integrante | NOT_EVALUATED | La aclaración oficial de Moodle indica que no se revisa en esta entrega; el estado local de Git no bloquea Entrega 1. |
| Nombre final requerido por Moodle | PARTIAL | Archivo usa `[[NUMERO_EQUIPO]]` hasta conocer el equipo. |
| Fecha y hora de Moodle confirmadas | PASS | Deadline oficial: `2026-10-04 23:59`, hora local de Moodle. |
| Fuentes PDF fuera de Git | PASS | `.gitignore` contiene `/sources/*.pdf`. |
| Arquitectura consistente con codigo/documentacion | PASS | `ConsoleApp -> ResidenceSystem -> OrderedStudentList -> Node -> Student`; pruebas separadas. |
| Sin estructuras fuera de alcance | PASS | Sin arboles, heaps, hash, grafos, sorting global ni colecciones que sustituyan la estructura. |
| Afirmaciones de complejidad sustentadas | PASS | Busqueda por ID declarada `O(n)`; no se afirma `O(1)`. |

## Estado de Git verificado (informativo)

La rama `master` no tiene commits y el contenido actual aparece como no rastreado. Es información de estado, no un requisito evaluado ni un bloqueo de Entrega 1 según la aclaración oficial de Moodle.

## HUMAN_INPUT_REQUIRED

1. `[[INTEGRANTES]]`: nombres completos de todos los integrantes.
2. `[[NUMERO_EQUIPO]]`: numero oficial del equipo para el nombre definitivo del PDF.
3. `[[REPO_URL]]`: enlace directo al repositorio compartido.

## Antes de subir a Moodle

Reemplazar los tres placeholders en el reporte/README y regenerar el PDF con los datos reales; verificar el enlace directo y subir una sola entrega grupal antes de `2026-10-04 23:59` (hora local de Moodle) con el nombre `Proyecto-Entrega1-Reporte-<numero de equipo>.pdf`. No se requieren commits mínimos ni código inicial para cerrar Entrega 1.
