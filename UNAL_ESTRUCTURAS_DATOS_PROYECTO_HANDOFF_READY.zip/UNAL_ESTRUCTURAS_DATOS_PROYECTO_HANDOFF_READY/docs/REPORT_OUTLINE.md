# Esquema del reporte (máximo 4 páginas)

1. **Título e integrantes**; problema escogido y enlace del repo.
2. **Problema y MVP:** necesidad, entradas/salidas y límites explícitos.
3. **Diagrama y flujo:** actores, componentes, secuencia de una operación clave.
4. **Estructuras y justificación:** invariante, operaciones, complejidades y alternativas descartadas por alcance.

Antes de exportar: revisar que ninguna decisión provisional se presente como confirmada y que todo dato de complejidad tenga fuente.

Estado: contenido técnico desarrollado en `DELIVERY1_REPORT_DRAFT.md`, con diagramas Mermaid y resultados ejecutados. Faltan datos humanos, selección/maquetación para cuatro páginas y exportación del PDF final.
