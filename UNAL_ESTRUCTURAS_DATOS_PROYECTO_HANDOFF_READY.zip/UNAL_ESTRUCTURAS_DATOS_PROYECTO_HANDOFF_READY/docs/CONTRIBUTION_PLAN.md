# Plan de contribuciones

Documento histórico de sugerencias de colaboración, no un requisito de Entrega 1. La aclaración oficial de Moodle indica que en esta entrega no se revisa la cantidad de commits por integrante. El proyecto actual tiene un único integrante pendiente de identificar; no se deben inventar participantes ni crear commits de relleno.

Si en una fase posterior se trabaja en equipo, cada commit debe seguir representando un cambio verificable y no un relleno. Eso no crea un mínimo de commits para Entrega 1.

Ejemplos futuros de mensajes: `docs: revisar requisitos de residencias`, `test: ampliar casos de reposicionamiento`, `report: maquetar entrega 1`. No reutilizarlos como commits vacíos.
