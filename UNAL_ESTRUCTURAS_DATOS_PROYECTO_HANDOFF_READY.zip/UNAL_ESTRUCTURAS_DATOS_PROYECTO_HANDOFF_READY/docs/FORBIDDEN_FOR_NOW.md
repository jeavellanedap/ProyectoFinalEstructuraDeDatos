# Fuera de alcance por ahora

- Árboles, BST, AVL y recorridos de árboles.
- Heaps y colas de prioridad.
- Tablas hash, maps y sets.
- Grafos, BFS/DFS, conectividad y topological sort.
- Algoritmos formales de sorting y ordenar una colección posteriormente mediante `sort`.
- Colecciones/librerías que oculten la estructura evaluada.
- Interfaces gráficas y frameworks no necesarios.

Estas exclusiones son del código actual. Solo una fuente posterior del curso puede autorizar un cambio de alcance.
