# Checklist de Entrega 1

- [ ] Título provisional listo; faltan integrantes reales.
- [x] Descripción clara del problema elegido.
- [x] Diagrama general: actores, componentes y relaciones.
- [x] Estructuras escogidas y justificación.
- [x] MVP / requisitos funcionales clave.
- [x] Flujo general y papel de cada estructura.
- [ ] Reporte PDF de máximo 4 páginas.
- [ ] Enlace directo al repositorio al final del reporte.
- [ ] `README.md` operativo; faltan integrantes reales y URL.
- [x] `README.md` presente (único requisito del prototipo de software para Entrega 1).
- [x] Código, pruebas y estructura inicial presentes como trabajo adicional opcional; no son requisito de entrega.
- [x] Cantidad de commits por integrante: no evaluada en esta entrega.
- [x] Fecha límite registrada: 2026-10-04 23:59, hora local de Moodle.
- [ ] Un envío grupal y nombre de archivo validado en Moodle.
