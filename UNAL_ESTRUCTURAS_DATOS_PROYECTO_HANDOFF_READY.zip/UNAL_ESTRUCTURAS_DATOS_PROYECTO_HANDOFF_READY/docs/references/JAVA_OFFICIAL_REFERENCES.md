# Referencias oficiales de Java

Java fue seleccionado por decisión del proyecto; la especificación permite cualquier lenguaje. Estas referencias respaldan únicamente las APIs básicas usadas por la consola del MVP.

Verificadas el 2026-10-04 contra la documentación oficial de Oracle Java SE 8:

- `java.util.Scanner`: https://docs.oracle.com/javase/8/docs/api/java/util/Scanner.html
- `java.lang.Integer`: https://docs.oracle.com/javase/8/docs/api/java/lang/Integer.html
- `java.lang.System`: https://docs.oracle.com/javase/8/docs/api/java/lang/System.html

`String`, arrays, excepciones básicas y construcciones de control pertenecen al lenguaje/base estándar y no sustituyen la estructura de datos evaluada. No se usan colecciones ni dependencias externas.
