# Índice de fuentes primarias locales

Los seis PDFs de este índice están disponibles físicamente en `../../sources/` para la auditoría documental. Se excluyen del control de versiones mediante `/.gitignore`; deben conservarse localmente y no se sustituyen por resúmenes Markdown.

| Nombre local | Nombre original | Propósito | Alcance autorizado | Tipo |
|---|---|---|---|---|
| `PROBLEMAS_A_RESOLVER.pdf` | `PROBLEMAS A RESOLVER.pdf` | Cuatro ideas/propuestas de problema. | Consultar directamente si el equipo confirma una propuesta. La aclaración de Moodle precisa que no obliga a seleccionar ni resolver una. | Propuestas del curso |
| `ESPECIFICACION_ENTREGA1_PROYECTO.pdf` | `Especificación_Entrega1_Proyecto.pdf` | Entregables, criterios, límites y fases de Entrega 1. | Consultar directamente para requisitos de la entrega y cualquier afirmación sobre lenguaje. No sustituye una decisión humana de lenguaje. | Normativa del proyecto |
| `GUIDE_TO_DATA_STRUCTURES.pdf` | `Guide to Data Structures_A Concise Introduction Using Java.pdf` | Referencia académica principal para estructuras y análisis. | **Solo capítulos 1–7 para código y decisiones actuales. Capítulos 8+ fuera de alcance.** | Académica |
| `ARRAYS_AND_LINKED_LISTS_RHODES.pdf` | `Arrays and Linked Lists - Neil Rhodes-UCSD.pdf` | Arrays, listas enlazadas y complejidades. | Apoyo académico para estructuras permitidas; no amplía el alcance más allá de las reglas del proyecto. | Académica |
| `STACKS_AND_QUEUES_RHODES.pdf` | `05_2_stacks_and_queues.pdf` | ADT y representaciones de pilas y colas. | Apoyo académico para stacks/queues, si resultan pertinentes al problema confirmado. | Académica |
| `DYNAMIC_ARRAYS_AMORTIZED_ANALYSIS_RHODES.pdf` | `05_4_dynamic_arrays_and_amortized_analysis.pdf` | Arreglos dinámicos y análisis amortizado. | Apoyo académico para `size`, `capacity`, crecimiento y complejidad amortizada. | Académica |

Estado de copia: los seis archivos se validaron por existencia local y tamaño positivo durante `SOURCE-BOOTSTRAP`. `SOURCE_AUDIT` se completó con resultado `PASS` y citas por página en `../SOURCE_AUDIT.md`. Posteriormente, el usuario confirmó `RESIDENCIAS_UNAL` y `JAVA`; la aclaración oficial posterior de Moodle está en `../MOODLE_CLARIFICATION.md` y prevalece ante conflicto de interpretación de Entrega 1.
