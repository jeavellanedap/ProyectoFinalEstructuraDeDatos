# Temas permitidos actualmente

- Análisis básico de tiempo y notación Big-O.
- Abstracción, ADT e interfaces cuando el lenguaje y el curso lo respalden.
- Arreglos, arreglos dinámicos y análisis amortizado.
- Nodos/referencias; listas singly y doubly linked.
- Listas enlazadas ordenadas mediante inserción que preserve el invariante.
- Stacks y queues con arrays o referencias.
- Validación básica, consola y pruebas simples.

El uso concreto depende de que sea pertinente para el problema confirmado y quede trazado.
