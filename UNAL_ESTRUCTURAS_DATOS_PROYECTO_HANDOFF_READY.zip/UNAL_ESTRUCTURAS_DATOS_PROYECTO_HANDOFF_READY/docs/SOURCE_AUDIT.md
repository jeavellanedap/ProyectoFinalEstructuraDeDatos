# SOURCE_AUDIT

Fecha: 2026-10-04

> Nota posterior: esta auditoría registró problema y lenguaje como pendientes en el momento de SOURCE_AUDIT. Después, el usuario confirmó explícitamente `RESIDENCIAS_UNAL` y `JAVA`; el estado vigente está en `DECISIONS.md` e `IMPLEMENTATION_STATUS.md`.

`SOURCE_AUDIT_RESULT = PASS`

Las seis fuentes primarias locales fueron abiertas y leídas directamente. En este documento, `p.` identifica la página física del PDF; cuando resulta útil, también se indica la página impresa del libro. Los Markdown del repositorio se usaron únicamente como objetos de auditoría, no como sustitutos de las fuentes.

## A. Resultado

| Conclusión | Clasificación | Resultado |
|---|---|---|
| Las seis fuentes requeridas existen, son legibles y contienen el material esperado. | COURSE_CONTENT_CONFIRMED | PASS |
| El límite operativo del Guide permanece en capítulos 1-7; el capítulo 8 comienza en la p. 209 del PDF. | REQUIREMENT_EXPLICIT | PASS |
| Los PDFs confirman las opciones disponibles, pero no eligen problema ni lenguaje por el equipo. | HUMAN_DECISION_REQUIRED | PASS, decisiones pendientes |

## B. Fuentes verificadas

| Fuente | Páginas relevantes | Alcance verificado | Estado |
|---|---:|---|---|
| `../sources/ESPECIFICACION_ENTREGA1_PROYECTO.pdf` | 1-3 | Objetivo, entregables, formato, aclaraciones, lenguaje, evaluación y fecha | VERIFIED |
| `../sources/PROBLEMAS_A_RESOLVER.pdf` | 1-4 | Cuatro problemas, requisitos y margen de decisión | VERIFIED |
| `../sources/GUIDE_TO_DATA_STRUCTURES.pdf` | 10-12, 15-208; frontera en 209 | Índice y capítulos 1-7: análisis, ADT, arrays, listas, referencias, pilas y colas | VERIFIED_WITH_CHAPTER_LIMIT |
| `../sources/ARRAYS_AND_LINKED_LISTS_RHODES.pdf` | 11, 33, 40, 51, 56-72, 84-118 | Arrays; listas singly/doubly; operaciones y complejidades condicionadas | VERIFIED |
| `../sources/STACKS_AND_QUEUES_RHODES.pdf` | 7, 110-111, 117, 158-163, 211 | ADT stack/queue, implementaciones con array/lista y complejidades | VERIFIED |
| `../sources/DYNAMIC_ARRAYS_AMORTIZED_ANALYSIS_RHODES.pdf` | 7-14, 44, 48-61, 70, 123, 157-174 | Arreglos dinámicos, `size`, `capacity`, redimensionamiento y análisis amortizado | VERIFIED |

## C. Requisitos confirmados de Entrega 1

| Requisito confirmado | PDF y página | Clasificación |
|---|---|---|
| El objetivo es elegir y abordar en equipo un problema concreto, explicar el plan y diseño, y justificar las estructuras de datos. | Especificación, p. 1 | REQUIREMENT_EXPLICIT |
| En Entrega 1 se presenta la idea y su justificación; el enfoque es técnico y no el de construir una aplicación completa. | Especificación, p. 1 | REQUIREMENT_EXPLICIT |
| El proyecto contempla dos entregas adicionales; la p. 1 menciona temas hasta AVL para Entrega 2 y heaps, conjuntos, hash y grafos para Entrega 3. Esto no amplía el alcance técnico autorizado de la fase actual. | Especificación, p. 1 | REQUIREMENT_EXPLICIT |
| Reporte técnico de máximo cuatro páginas. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| El reporte debe incluir título e integrantes, descripción del problema, diagrama del sistema con componentes/actores/relaciones, estructuras y justificación, boceto del MVP con requisitos funcionales clave, diagrama general de flujo y explicación del uso de las estructuras. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| Debe existir un repositorio compartido en una herramienta de control de versiones y participar todos los integrantes. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| El `README.md` debe incluir descripción, integrantes, lenguajes, instalación y estructura del proyecto. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| Se permiten archivos iniciales, estructuras parcialmente implementadas o plantillas con comentarios significativos; no tienen que estar completos, pero deben mostrar avance y orden. La fase SOURCE_AUDIT no autoriza crearlos todavía. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| Se requieren al menos tres commits por integrante; cada commit debe ser descriptivo y representar un avance concreto y manejable. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| El reporte se entrega en PDF con enlace directo al repositorio al final. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| La entrega es exclusivamente por Moodle, una sola entrega por grupo, con nombre `Proyecto-Entrega1-Reporte-<número de equipo>.pdf`. | Especificación, p. 2 | REQUIREMENT_EXPLICIT |
| La interfaz gráfica no es obligatoria ni el foco de evaluación; consola o archivos son válidos. La especificación también menciona una visualización opcional para facilitar comprensión. | Especificación, pp. 1 y 3 | REQUIREMENT_EXPLICIT |
| Puede utilizarse cualquier lenguaje de programación. Esto no selecciona un lenguaje. | Especificación, p. 3 | REQUIREMENT_EXPLICIT |
| Esta entrega se califica por completitud. Para entregas posteriores se anuncian criterios de optimalidad, profundidad del análisis de tiempos y uso de métodos/temas de clase; también se evalúa el aporte individual y todos deben dominar el tema. | Especificación, p. 3 | REQUIREMENT_EXPLICIT |
| La fecha y hora válidas son las indicadas en Moodle. | Especificación, p. 3 | REQUIREMENT_EXPLICIT |

## D. Problemas disponibles y requisitos confirmados

### Deportes UNAL

| Requisito | PDF y página | Clasificación |
|---|---|---|
| Registrar ID, nombre, deportes actuales y deportes de interés. | Problemas, p. 1 | REQUIREMENT_EXPLICIT |
| Agrupar automáticamente estudiantes que compartan al menos un deporte. | Problemas, p. 1 | REQUIREMENT_EXPLICIT |
| Determinar si un estudiante está conectado directa o indirectamente con alguien que practica un deporte de su interés e indicar cuando no hay conexión. | Problemas, p. 1 | REQUIREMENT_EXPLICIT |
| Acceder mediante ID a los datos completos de un estudiante y permitir eliminarlo. | Problemas, p. 1 | REQUIREMENT_EXPLICIT |
| Contar cuántos estudiantes practican cada deporte y listarlos en orden. | Problemas, p. 1 | REQUIREMENT_EXPLICIT |
| La clave/dirección de ese orden, formatos de entrada y representación no están completamente definidos. | Problemas, p. 1 | HUMAN_DECISION_REQUIRED |

### Residencias UNAL

| Requisito | PDF y página | Clasificación |
|---|---|---|
| Registrar ID, nombre completo y puntaje socioeconómico; menor puntaje implica mayor prioridad. | Problemas, p. 2 | REQUIREMENT_EXPLICIT |
| Ingresar el número de cupos disponibles y asignarlos comenzando por los puntajes más bajos. | Problemas, p. 2 | REQUIREMENT_EXPLICIT |
| Acceder mediante ID único a los datos y listar estudiantes en orden creciente de puntaje. | Problemas, p. 2 | REQUIREMENT_EXPLICIT |
| Listar quienes obtuvieron residencia y quienes no. | Problemas, p. 2 | REQUIREMENT_EXPLICIT |
| Modificar un puntaje actualizando la posición y eliminar estudiantes. | Problemas, p. 2 | REQUIREMENT_EXPLICIT |
| El criterio de desempate entre puntajes iguales no está definido. | Problemas, p. 2 | HUMAN_DECISION_REQUIRED |

### Graduación UNAL

| Requisito | PDF y página | Clasificación |
|---|---|---|
| Determinar el número mínimo de semestres para completar todas las asignaturas obligatorias, respetando prerrequisitos y máximo de materias por semestre. | Problemas, p. 3 | REQUIREMENT_EXPLICIT |
| Registrar asignaturas con ID numérico y lista de prerrequisitos. | Problemas, p. 3 | REQUIREMENT_EXPLICIT |
| Acceder a una asignatura por ID, calcular el mínimo de semestres y mostrar las asignaturas de cada semestre. | Problemas, p. 3 | REQUIREMENT_EXPLICIT |
| No se define cómo resolver múltiples planes mínimos equivalentes ni cómo tratar entradas inválidas como ciclos; cualquier política requeriría decisión y justificación. | Problemas, p. 3 | HUMAN_DECISION_REQUIRED |

### Reservas de Espacio UNAL

| Requisito | PDF y página | Clasificación |
|---|---|---|
| Gestionar espacios, reservas, fusiones e historial de uso ordenado, sin información de usuarios. | Problemas, p. 4 | REQUIREMENT_EXPLICIT |
| Registrar ID único, tipo y disponibilidad horaria del espacio. | Problemas, p. 4 | REQUIREMENT_EXPLICIT |
| Reservar indicando espacio e inicio/fin, evitando dos reservas del mismo espacio en el mismo horario. | Problemas, p. 4 | REQUIREMENT_EXPLICIT |
| Fusionar espacios compatibles cuando ambos estén disponibles. | Problemas, p. 4 | REQUIREMENT_EXPLICIT |
| Listar espacios ordenados por cantidad total de reservas y consultar disponibilidad actual. | Problemas, p. 4 | REQUIREMENT_EXPLICIT |
| Compatibilidad, límites de intervalos, criterio de empate, persistencia de fusiones y clave del historial ordenado no se definen. | Problemas, p. 4 | HUMAN_DECISION_REQUIRED |

La nota común de las pp. 1-4 deja abiertos formatos de entrada, representación y decisiones menores, siempre que no se alteren la lógica central ni las estructuras obligatorias indicadas. Esta libertad no autoriza omitir requisitos.

## E. Alcance académico autorizado

| Concepto | Fuente | Página/capítulo | Clasificación | Estado |
|---|---|---|---|---|
| Análisis elemental y Big-O: `O(1)`, `O(log n)`, `O(n)`, `O(n log n)`, `O(n²)` | Guide | cap. 1, PDF pp. 16-21 (libro pp. 2-7) | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Abstracción de datos/procedimientos, ADT e interfaces | Guide | cap. 1, PDF pp. 22-26 (libro pp. 8-12) | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Stacks con arrays | Guide | cap. 2, PDF pp. 31-61 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Queues con arrays | Guide | cap. 3, PDF pp. 62-88 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Listas con arrays, búsqueda, inserción y eliminación | Guide | cap. 4, PDF pp. 89-120 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Referencias, objetos, nodos y enlaces | Guide | cap. 5, PDF pp. 121-144 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Listas enlazadas ordenadas y doubly linked | Guide | cap. 6, PDF pp. 145-182 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Stacks y queues mediante referencias | Guide | cap. 7, PDF pp. 183-208 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Acceso constante en arrays; costos de inserción/eliminación según posición | Arrays and Linked Lists | PDF pp. 11 y 33 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Listas singly/doubly, punteros head/tail y complejidades condicionadas | Arrays and Linked Lists | PDF pp. 40, 51, 94, 95-118 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| ADT stack y queue; implementaciones con array o lista | Stacks and Queues | PDF pp. 7, 110-111, 117, 158-163, 211 | COURSE_CONTENT_CONFIRMED | ALLOWED |
| Arreglo dinámico, `size`, `capacity`, duplicación y análisis amortizado | Dynamic Arrays | PDF pp. 7-14, 44, 48-61, 70, 123 | COURSE_CONTENT_CONFIRMED | ALLOWED |

Que un concepto esté `ALLOWED` no lo convierte en adecuado para el problema futuro; esa adecuación será una recomendación de diseño posterior.

## F. Elementos fuera de alcance actual

| Elemento | Evidencia | Clasificación | Estado |
|---|---|---|---|
| Árboles binarios, BST y sus recorridos | Guide cap. 8 inicia en PDF p. 209; límite local: caps. 1-7 | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |
| Sorting formal (insertion, quick, radix) | Índice del Guide, PDF p. 13, cap. 9 | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |
| Heaps, priority queues y heap sort | Índice del Guide, PDF p. 13, cap. 10 | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |
| Hashing, HashMap y HashSet | Índice del Guide, PDF p. 14, cap. 11 | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |
| Grafos, BFS/DFS y ordenamiento topológico | No aparecen dentro de Guide caps. 1-7; la especificación solo menciona grafos como tema de Entrega 3 en p. 1 | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |
| Colecciones o APIs que sustituyan la estructura evaluada | Regla académica local; Guide p. 26 explica por qué se estudia la implementación propia | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |
| Arquitectura definitiva, clases de negocio e interfaz | Solicitud expresa de SOURCE_AUDIT | REQUIREMENT_EXPLICIT | OUT_OF_SCOPE |

## G. Complejidades verificadas

| Afirmación | Evidencia | Clasificación | Condición |
|---|---|---|---|
| Acceso por índice de array: `O(1)` | Arrays and Linked Lists, p. 11; Dynamic Arrays, p. 48 | COURSE_CONTENT_CONFIRMED | Índice válido y acceso directo al arreglo |
| Añadir/eliminar al comienzo o medio de un array: `O(n)`; al final: `O(1)` en la tabla del material | Arrays and Linked Lists, p. 33 | COURSE_CONTENT_CONFIRMED | La afirmación del final depende de la representación y de disponer de espacio; no equivale al peor caso de un arreglo dinámico |
| `Get`/`Set`: `O(1)`, `Remove(i)`: `O(n)`, `Size`: `O(1)` | Dynamic Arrays, pp. 48-52 | COURSE_CONTENT_CONFIRMED | Arreglo dinámico con `size` almacenado |
| `PushBack` dinámico: peor caso `O(n)` al redimensionar; `O(1)` amortizado con crecimiento geométrico | Dynamic Arrays, pp. 44, 50, 54, 70 y 123 | COURSE_CONTENT_CONFIRMED | El material duplica `capacity`; crecer por cantidad constante produce `O(n)` amortizado, p. 168 |
| Singly linked list: `Find` y `Erase` `O(n)`; `PushFront`/`PopFront` `O(1)`; `PushBack` `O(1)` solo con tail | Arrays and Linked Lists, p. 94 | COURSE_CONTENT_CONFIRMED | Según presencia de tail y operación exacta |
| Doubly linked con tail: inserción/eliminación al final `O(1)`; encontrar elemento arbitrario `O(n)` | Arrays and Linked Lists, pp. 102 y 115-118 | COURSE_CONTENT_CONFIRMED | Para insertar/eliminar un nodo conocido, los enlaces necesarios ya están disponibles |
| Operaciones de stack y queue presentadas: `O(1)` | Stacks and Queues, pp. 110 y 211 | COURSE_CONTENT_CONFIRMED | Queue enlazada con tail o representación de array descrita en el material |
| Buscar un ID en una lista enlazada sería `O(n)` | Derivación de `Find(Key) O(n)`, Arrays and Linked Lists, p. 94 | INFERENCE | ID usado como key y ausencia de índice adicional |
| Insertar manteniendo orden en una lista sería `O(n)` en peor caso | Derivación de búsqueda lineal más enlace constante | INFERENCE | Se recorre desde head para localizar la posición; no es una complejidad funcional confirmada hasta elegir diseño |

## H. Contradicciones o errores encontrados

| Hallazgo | Corrección | Clasificación |
|---|---|---|
| `SOURCE_BOOTSTRAP_STATUS.md`, `DECISIONS.md` y `references/SOURCES_INDEX.md` aún describían SOURCE_AUDIT como pendiente. | Se actualizó el estado a PASS sin cerrar problema o lenguaje. | REQUIREMENT_EXPLICIT |
| `COMPLEXITY_BASELINE.md` decía “inserción/eliminación en posición de arreglo: O(n)”, lo que era demasiado amplio frente a la distinción inicio/medio/final de la fuente. | Se precisaron posiciones y condiciones. | COURSE_CONTENT_CONFIRMED |
| La fila de `pushBack` solo mostraba costo amortizado y omitía el peor caso. | Se registraron `O(n)` peor caso y `O(1)` amortizado bajo crecimiento geométrico. | COURSE_CONTENT_CONFIRMED |
| Las complejidades inferidas para ID e inserción ordenada no estaban diferenciadas de afirmaciones directas. | Se añadió clasificación y fuente/condición. | INFERENCE |
| No se encontraron contradicciones verificables en `PROJECT_BRIEF.md` o `DELIVERY1_CHECKLIST.md`; sus afirmaciones coinciden con las pp. 1-3 de la especificación. | Sin cambios. | REQUIREMENT_EXPLICIT |

La especificación contiene una posible ambigüedad interna: en p. 3 dice que la interfaz visual es opcional y “no será calificable”, pero a continuación señala que una interpretación visual puede tener “nota adicional”. No se altera ninguna regla del repositorio: para esta fase no se crea interfaz y cualquier valoración futura debe aclararse con el docente.

## I. Archivos modificados

| Archivo | Motivo exacto |
|---|---|
| `docs/SOURCE_AUDIT.md` | Registrar la salida formal A-K con evidencia primaria y páginas exactas. |
| `docs/DECISIONS.md` | Marcar SOURCE_AUDIT como PASS y añadir citas exactas manteniendo las decisiones humanas en PENDING. |
| `docs/REQUIREMENTS_TRACEABILITY.md` | Sustituir páginas pendientes por evidencia verificada y clasificaciones. |
| `docs/COMPLEXITY_BASELINE.md` | Corregir condiciones de arrays, añadir peor caso de `pushBack` y separar inferencias. |
| `docs/SOURCE_BOOTSTRAP_STATUS.md` | Evitar que el próximo paso obsoleto indique ejecutar una auditoría ya completada. |
| `docs/references/SOURCES_INDEX.md` | Actualizar el estado de fase sin modificar el alcance de las fuentes. |

## J. Estado al cierre de SOURCE_AUDIT y decisiones entonces requeridas

`PROJECT_PROBLEM_DECISION = PENDING`

`LANGUAGE_DECISION = PENDING`

| Decisión requerida | Clasificación |
|---|---|
| Elegir explícitamente uno de los cuatro problemas. | HUMAN_DECISION_REQUIRED |
| Elegir lenguaje y versión; cualquier lenguaje está permitido por la especificación, p. 3. | HUMAN_DECISION_REQUIRED |
| Confirmar integrantes, número de equipo y URL del repositorio. | HUMAN_DECISION_REQUIRED |
| Consultar y registrar fecha/hora vigentes en Moodle. | HUMAN_DECISION_REQUIRED |
| Para el problema elegido, resolver los detalles abiertos comunes y específicos enumerados en la sección D. | HUMAN_DECISION_REQUIRED |
| Decidir si habrá visualización opcional en una fase posterior; no forma parte de SOURCE_AUDIT. | HUMAN_DECISION_REQUIRED |

## K. Próximo paso recomendado

El equipo debe revisar esta auditoría y elegir explícitamente problema y lenguaje. Después, y no antes, se completa la trazabilidad funcional del problema elegido, se consulta documentación oficial del lenguaje confirmado y se propone un diseño dentro del alcance académico autorizado. No se avanza a arquitectura definitiva ni implementación durante SOURCE_AUDIT.

## Addendum - OFFICIAL_COURSE_CLARIFICATION (2026-10-04)

Esta sección añade evidencia oficial posterior sin borrar ni alterar las conclusiones históricas anteriores de `SOURCE_AUDIT`.

La captura oficial de Moodle aportada el 2026-10-04 prevalece sobre las interpretaciones anteriores cuando exista conflicto para Entrega 1. Registra: fecha límite domingo 4 de octubre de 2026, 11:59 PM (`2026-10-04 23:59`, hora local de Moodle); los cuatro casos de `PROBLEMAS_A_RESOLVER.pdf` son ideas/propuestas y no una selección obligatoria; E2 y E3 serán implementaciones diferentes; para el prototipo de E1 solo se requiere `README.md`; archivos iniciales, código y demás son opcionales; y no se revisa la cantidad de commits por integrante.

Por ello, las filas históricas de la sección C sobre archivos iniciales/estructuras parcialmente implementadas y tres commits describen lo que decía el PDF de especificación, pero no se usan como requisitos evaluados ni bloqueos de Entrega 1. `RESIDENCIAS_UNAL` permanece como decisión explícita del equipo, no como selección impuesta por el profesor. Las decisiones y el impacto vigente están consolidados en `MOODLE_CLARIFICATION.md`, `DECISIONS.md` y `DELIVERY1_FINAL_CHECK.md`.
