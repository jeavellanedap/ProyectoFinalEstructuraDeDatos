# Registro de decisiones

| Estado | Clasificación | Decisión | Evidencia / justificación |
|---|---|---|---|
| CONFIRMED | REQUIREMENT_EXPLICIT | Alcance del Guide limitado a capítulos 1-7 | Regla del proyecto; el capítulo 8 comienza en `GUIDE_TO_DATA_STRUCTURES.pdf`, p. 209. |
| CONFIRMED | REQUIREMENT_EXPLICIT | `SOURCE_AUDIT_RESULT = PASS` | Los seis PDFs fueron verificados directamente en `SOURCE_AUDIT.md`. |
| CONFIRMED | OFFICIAL_COURSE_CLARIFICATION | `MOODLE_CLARIFICATION_SYNC = PASS` | Captura oficial de Moodle del 2026-10-04. Es evidencia posterior y más específica; prevalece sobre interpretaciones previas en conflicto. Véase `MOODLE_CLARIFICATION.md`. |
| CONFIRMED | OFFICIAL_COURSE_CLARIFICATION | Fecha límite de Entrega 1: `2026-10-04 23:59` hora local de Moodle | La captura de Moodle fija domingo 4 de octubre de 2026, 11:59 PM. |
| CONFIRMED | OFFICIAL_COURSE_CLARIFICATION | Para Entrega 1, del prototipo de software solo se requiere `README.md` | Inicialización de archivos, código, pruebas y estructuras parcialmente implementadas son opcionales. El baseline actual es trabajo adicional válido. |
| CONFIRMED | OFFICIAL_COURSE_CLARIFICATION | No se evalúa la cantidad de commits por integrante en Entrega 1 | No es un bloqueo ni un criterio de cierre de esta entrega. |
| CONFIRMED | OFFICIAL_COURSE_CLARIFICATION | Entregas 2 y 3 serán implementaciones diferentes | No se deben diseñar aún ni asumir como evoluciones obligatorias de esta implementación. |
| CONFIRMED | OFFICIAL_COURSE_CLARIFICATION | Los cuatro casos de `PROBLEMAS_A_RESOLVER.pdf` son propuestas | `RESIDENCIAS_UNAL` continúa como decisión humana del proyecto, no como imposición docente. |
| CONFIRMED | HUMAN_DECISION_REQUIRED | `PROJECT_PROBLEM_DECISION = RESIDENCIAS_UNAL` | Decisión explícita del usuario del 2026-10-04; alcance funcional de la propuesta en `PROBLEMAS_A_RESOLVER.pdf`, p. 2. Moodle aclara que no era una selección obligatoria. |
| CONFIRMED | HUMAN_DECISION_REQUIRED | `LANGUAGE_DECISION = JAVA` | Decisión explícita del usuario del 2026-10-04. La especificación permite cualquier lenguaje, p. 3; Java no es una imposición del profesor. |
| CONFIRMED | PROJECT_DESIGN_DECISION | Orden total `(puntaje socioeconómico ascendente, ID ascendente)` | El puntaje ascendente es requisito; el ID resuelve empates de forma determinista. |
| CONFIRMED | PROJECT_DESIGN_DECISION | ID y puntaje representados con `int` | Representación sencilla para el MVP; el enunciado no exige IDs contiguos ni puntajes decimales. |
| CONFIRMED | PROJECT_DESIGN_DECISION | IDs únicos; nombre no nulo ni vacío; `availableSlots >= 0` | Unicidad exigida por el enunciado; las otras validaciones aseguran registros y cupos coherentes sin inventar rangos de puntaje. |
| CONFIRMED | PROJECT_DESIGN_DECISION | Una ordered singly linked list canónica con `head` y `size`; sin `tail` | Guide caps. 5-6 y Arrays and Linked Lists. Las operaciones requeridas no obtienen una ventaja relevante de `tail`. |
| CONFIRMED | PROJECT_DESIGN_DECISION | Admitidos y no admitidos se derivan del orden y de `availableSlots` | Evita tres colecciones sincronizadas y duplicación de estado. |
| CONFIRMED | PROJECT_DESIGN_DECISION | Cambiar puntaje retira y reinserta el estudiante | Conserva el invariante sin sorting global. |
| CONFIRMED | INFERENCE | Consultar por ID es `O(n)` | `Find(Key)` en singly linked list es `O(n)`; no se autoriza hashing en el alcance actual. “Acceder mediante ID” no se interpreta como promesa de `O(1)`. |
| PENDING | HUMAN_DECISION_REQUIRED | Nombre del único integrante, número de equipo y URL del repositorio | Deben completarse con datos reales para sustituir placeholders y generar el PDF definitivo. |

## Estado local de Java

`java -version` detectó Oracle Java Runtime `1.8.0_51` en `PATH`, sin `javac`. La validación se ejecutó con un JDK portátil temporal Temurin OpenJDK/Javac `1.8.0_504`, sin copiarlo al repositorio. Ninguna de estas versiones se convierte en requisito académico.
