# MOODLE_CLARIFICATION

Fecha de registro: 2026-10-04  
Contexto: captura oficial de Moodle aportada por el usuario para Entrega 1.

`MOODLE_CLARIFICATION_SYNC = PASS`

## Autoridad y precedencia

Esta captura es evidencia oficial posterior y más específica que las interpretaciones documentales previas. Cuando exista conflicto de interpretación para Entrega 1, esta aclaración de Moodle prevalece. No borra la trazabilidad histórica de los PDFs; precisa cómo se aplican a esta entrega.

## Resumen fiel de la aclaración

- Fecha límite: domingo, **4 de octubre de 2026, 11:59 PM**; se registra como `2026-10-04 23:59`, hora local de Moodle.
- El PDF `PROBLEMAS_A_RESOLVER` presenta ideas de problemas; no es obligatorio resolver ni seleccionar uno de sus cuatro casos.
- Entrega 2 y Entrega 3 serán implementaciones diferentes.
- Para Entrega 1, del prototipo de software solamente se requiere el `README.md`.
- Inicializar archivos, implementar código, pruebas u otros elementos de software es opcional para esta entrega.
- En Entrega 1 no se revisará la cantidad de commits por integrante.

## Requisitos que modifica o reclasifica

| Interpretación previa | Interpretación vigente tras Moodle |
|---|---|
| Archivos iniciales, prototipo parcial o MVP implementado como condición de cierre | Opcionales. El código actual es trabajo adicional válido, no requisito. |
| Tres commits por integrante como bloqueo | No evaluado en Entrega 1; no bloquea el envío. |
| Cuatro problemas del PDF como selección obligatoria | Propuestas. `RESIDENCIAS_UNAL` sigue siendo una decisión del equipo. |
| E2/E3 como evolución necesariamente continua de este MVP | No se asume. Moodle indica implementaciones diferentes y no se diseñan todavía. |
| Fecha/hora pendiente por confirmar | Confirmada: `2026-10-04 23:59`, hora local de Moodle. |

## Lo que no modifica

- El reporte técnico, su contenido solicitado, el máximo de cuatro páginas, el enlace al repositorio y el envío único en Moodle siguen siendo obligaciones de Entrega 1 según la especificación.
- Los datos humanos siguen siendo necesarios para el archivo definitivo: nombre del único integrante, número de equipo y URL del repositorio.
- Las decisiones técnicas, el alcance de capítulos 1-7 y las restricciones internas del proyecto no se amplían por esta aclaración.
- El código existente no se elimina ni se convierte en requisito: se conserva como evidencia adicional del trabajo del proyecto.

## Impacto sobre Entrega 1

El único requisito del prototipo de software es `README.md`. No se deben añadir funcionalidades, pruebas ni arquitectura para intentar satisfacer un requisito inexistente. Los pendientes reales son sustituir los datos humanos, regenerar el PDF final y subir una única entrega grupal antes de la hora límite.

## Impacto sobre la planificación futura

No se planifican ni se implementan aún Entrega 2 o Entrega 3. Cuando el curso publique su alcance, se tratarán como implementaciones diferentes y se documentarán desde evidencia nueva, sin asumir que deban evolucionar `RESIDENCIAS_UNAL` ni su lista enlazada actual.
