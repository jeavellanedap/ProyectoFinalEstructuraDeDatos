# Project brief

## Qué pide la Entrega 1

No se exige una solución completa: se debe proponer y justificar técnicamente una solución, con foco en estructuras de datos, operaciones y eficiencia. La interfaz gráfica no es el foco. La aclaración oficial posterior de Moodle indica que, para esta entrega, del prototipo de software únicamente se requiere el `README.md`.

## Entregables verificados desde la especificación

- Reporte técnico PDF de máximo **4 páginas**: título/integrantes, problema, diagrama general, estructuras y justificación, MVP/requisitos funcionales, flujo y papel de las estructuras.
- Enlace directo al repositorio al final del reporte.
- Repositorio compartido con `README.md`; los archivos iniciales, las plantillas, el código y las pruebas son opcionales en Entrega 1.
- La cantidad de commits por integrante no se revisa en esta entrega.
- Un único envío grupal en Moodle, con el nombre indicado en la especificación, antes de `2026-10-04 23:59` (hora local de Moodle).

Los cuatro casos del PDF son ideas/propuestas, no una selección obligatoria. `RESIDENCIAS_UNAL` es la decisión vigente del equipo. Se pueden definir detalles menores sin cambiar la lógica central.
