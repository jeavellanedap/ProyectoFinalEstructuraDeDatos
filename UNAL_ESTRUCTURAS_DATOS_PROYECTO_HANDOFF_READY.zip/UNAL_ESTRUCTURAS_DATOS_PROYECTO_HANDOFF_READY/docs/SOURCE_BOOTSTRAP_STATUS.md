# SOURCE-BOOTSTRAP — PASS

Fecha de preparación: 2026-10-04

## Estado

`SOURCE_BOOTSTRAP=PASS`. Las seis fuentes primarias requeridas están presentes en `../sources/`, son archivos PDF no vacíos y están excluidas de Git mediante `/.gitignore`. Esta fase solo deja las fuentes accesibles; no constituye una auditoría de contenido ni cierra decisiones pendientes.

## Archivos disponibles

| PDF local | Clasificación | Restricción principal |
|---|---|---|
| `../sources/PROBLEMAS_A_RESOLVER.pdf` | Propuestas del curso | Registrar alcance funcional solo si el equipo confirma una propuesta; Moodle aclara que no es obligatorio seleccionar ni resolver una. |
| `../sources/ESPECIFICACION_ENTREGA1_PROYECTO.pdf` | Normativa del proyecto | Registrar entregables y cualquier alcance de lenguaje solo con cita de página. |
| `../sources/GUIDE_TO_DATA_STRUCTURES.pdf` | Académica | **Solo capítulos 1–7 para código y decisiones actuales; capítulos 8+ fuera de alcance.** |
| `../sources/ARRAYS_AND_LINKED_LISTS_RHODES.pdf` | Académica | Apoyo para arrays/listas dentro del alcance vigente. |
| `../sources/STACKS_AND_QUEUES_RHODES.pdf` | Académica | Apoyo para stacks/queues dentro del alcance vigente. |
| `../sources/DYNAMIC_ARRAYS_AMORTIZED_ANALYSIS_RHODES.pdf` | Académica | Apoyo para arreglos dinámicos y análisis amortizado. |

## Restricciones que siguen vigentes

- `PROJECT_PROBLEM_DECISION=RESIDENCIAS_UNAL` por decisión humana posterior.
- `LANGUAGE_DECISION=JAVA` por decisión humana posterior.
- `SOURCE_AUDIT_RESULT=PASS`; cualquier implementación debe conservar su trazabilidad.
- Los Markdown de este workspace no sustituyen a los PDFs primarios.
- Los PDFs son locales y no se versionan salvo decisión humana posterior.

## Fase posterior completada

`SOURCE_AUDIT_RESULT=PASS` el 2026-10-04. La auditoría directa, sus citas por página y las decisiones que continúan pendientes están en `SOURCE_AUDIT.md`. Este estado de bootstrap solo confirma disponibilidad física y no sustituye la auditoría.
