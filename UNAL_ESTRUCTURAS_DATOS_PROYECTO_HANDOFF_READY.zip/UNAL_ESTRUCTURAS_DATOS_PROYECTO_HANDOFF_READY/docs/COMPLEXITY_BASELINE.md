# Línea base de complejidad y honestidad

| Operación / estructura permitida | Complejidad esperada | Condición | Evidencia | Clasificación |
|---|---:|---|---|---|
| Acceso por índice en arreglo | O(1) | Índice válido. | Arrays and Linked Lists, p. 11; Dynamic Arrays, p. 48 | COURSE_CONTENT_CONFIRMED |
| Búsqueda de elemento arbitrario en lista | O(n) | Sin índice adicional. | Arrays and Linked Lists, pp. 94 y 116-118 | COURSE_CONTENT_CONFIRMED |
| Inserción/eliminación al inicio o medio de arreglo | O(n) | Por desplazamientos. | Arrays and Linked Lists, p. 33 | COURSE_CONTENT_CONFIRMED |
| Inserción/eliminación al final de arreglo | O(1) | Según la tabla de la fuente y con espacio/representación adecuados; no cubre redimensionamiento dinámico. | Arrays and Linked Lists, p. 33 | COURSE_CONTENT_CONFIRMED |
| `pushBack` de arreglo dinámico | O(n) peor caso; O(1) amortizado | Crecimiento geométrico y copia al redimensionar. | Dynamic Arrays, pp. 44, 50, 54, 70 y 123 | COURSE_CONTENT_CONFIRMED |
| Recorrer todos los nodos de una lista | O(n) | Debe visitar cada nodo. | Derivación del recorrido lineal | INFERENCE |
| Buscar ID en lista | O(n) | ID usado como key y sin índice adicional; no llamarlo acceso directo O(1). | Derivación de `Find(Key) O(n)`, Arrays and Linked Lists, p. 94 | INFERENCE |
| Insertar en lista ordenada | O(n) peor caso | Recorrido desde head para ubicar posición; enlace posterior constante. | Derivación de búsqueda lineal y Guide cap. 6 | INFERENCE |
| Tamaño almacenado de arreglo dinámico | O(1) | Solo si `size` se mantiene correctamente. | Dynamic Arrays, p. 52 | COURSE_CONTENT_CONFIRMED |

Reglas: declarar peor caso y amortizado cuando corresponda; nunca inferir una complejidad mejor por intención; registrar invariantes que justifican cada afirmación.

## Regla de trazabilidad antes de asociar una complejidad al proyecto

La tabla anterior es la base académica. Residencias y Java ya están confirmados; las operaciones concretas siguientes se auditarán contra el código real.

## Complejidades previstas para el MVP

| Operación | Peor caso previsto | Justificación previa a implementación | Estado |
|---|---:|---|---|
| `registerStudent` | O(n) | `findById` O(n) seguido de inserción ordenada O(n); recorridos sucesivos suman O(n). | VERIFIED |
| `findStudentById` | O(n) | Recorre desde `head`; el ID no coincide con el orden principal y no existe índice hash. | VERIFIED |
| `removeStudent` | O(n) | Recorre por ID y puede alcanzar el último nodo; desenlazar es O(1). | VERIFIED |
| `updateStudentScore` | O(n) | Retira por ID O(n) y reinserta ordenadamente O(n): O(n) + O(n) = O(n). | VERIFIED |
| `getStudentsOrdered` | O(n) | Recorre los `n` nodos y llena un array de tamaño `n`; espacio extra O(n). | VERIFIED |
| `getAcceptedStudents` | O(min(k,n)) | Crea y llena únicamente el prefijo de tamaño `min(k,n)`; espacio extra igual al resultado. | VERIFIED |
| `getRejectedStudents` | O(n) | Salta `min(k,n)` nodos y copia `n-min(k,n)`; la suma es `n`; espacio extra igual al resultado. | VERIFIED |
| `setAvailableSlots` | O(1) | Compara contra cero y asigna un entero; no recalcula colecciones. | VERIFIED |
| `size` / `isEmpty` | O(1) | Leen el campo `size`, mantenido en inserción/eliminación. | VERIFIED |
| `hasValidInvariant` | O(n) | Recorre una vez, compara pares consecutivos y contrasta el contador. | VERIFIED |

No hay operaciones amortizadas en la implementación actual. Las asignaciones de arrays de salida se contabilizan en el tiempo y espacio proporcional al resultado.
