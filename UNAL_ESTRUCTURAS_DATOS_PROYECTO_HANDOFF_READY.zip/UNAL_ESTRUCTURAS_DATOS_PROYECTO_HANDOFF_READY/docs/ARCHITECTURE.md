# Arquitectura del MVP - Residencias UNAL

Arquitectura mínima, sin frameworks ni capas artificiales:

```text
ConsoleApp
    |
    v
ResidenceSystem
    |
    v
OrderedStudentList --> Node --> Student

ResidenceSystemTest --> ResidenceSystem / OrderedStudentList
```

| Componente | Responsabilidad | No hace |
|---|---|---|
| `Student` | Mantener ID, nombre completo y puntaje. | No decide cupos ni ordena colecciones. |
| `OrderedStudentList` | Implementar manualmente nodos, inserción ordenada, búsqueda, eliminación, reposicionamiento, recorridos y `size`. | No imprime ni conoce reglas de consola. |
| `ResidenceSystem` | Validar operaciones del caso de uso y derivar admitidos/no admitidos desde la lista y los cupos. | No mantiene listas duplicadas. |
| `ConsoleApp` | Demostrar el MVP mediante entrada/salida básica. | No implementa estructuras ni reglas de asignación. |
| `ResidenceSystemTest` | Ejecutar verificaciones sin dependencias externas, incluidos invariantes y bordes. | No sustituye la aplicación. |

## Estructura e invariante

La estructura canónica es una ordered singly linked list con `head` y contador `size`. Cada nodo contiene un `Student` y una referencia `next`.

Para cada par consecutivo `current`, `next`:

```text
current.score < next.score
OR
(current.score == next.score AND current.id < next.id)
```

El ID es único en toda la lista. `size` coincide con la cantidad de nodos alcanzables desde `head`.

No se almacena `tail`: insertar requiere localizar la posición por orden, buscar/eliminar requiere recorrido por ID y los listados parten de `head`; por tanto, `tail` no mejora la complejidad de las operaciones requeridas.

## Flujo de asignación

```text
registrar / modificar / eliminar
              |
              v
mantener orderedStudents por (score, ID)
              |
              v
accepted = primeros min(availableSlots, size)
rejected = nodos restantes
```

La asignación es estado derivado: cambiar cupos no mueve ni copia estudiantes.
