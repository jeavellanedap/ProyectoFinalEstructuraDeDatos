# Sistema priorizado de asignacion de Residencias UNAL

**Equipo:** [[NUMERO_EQUIPO]]  
**Integrantes:** [[INTEGRANTES]]

## Problema y proposito

Residencias UNAL debe atender solicitudes de alojamiento cuando los cupos son limitados. Cada estudiante tiene un ID unico, nombre completo y puntaje socioeconomico; un puntaje menor indica mayor prioridad. El sistema registra, consulta, modifica y elimina estudiantes, mantiene el orden de prioridad y asigna los cupos desde los puntajes mas bajos. El MVP se implementa en Java por decision del equipo; la especificacion permite cualquier lenguaje.

## Sistema propuesto

```text
Usuario
   | registrar, consultar, modificar, eliminar, definir cupos, listar
   v
ConsoleApp  --->  ResidenceSystem  --->  OrderedStudentList  --->  Node  --->  Student
                     |                         |
                     | reglas y cupos           | lista enlazada manual
                     v                         v
                resultados                 orden (puntaje, ID)

ResidenceSystemTest  ---- valida por separado ----> ResidenceSystem / OrderedStudentList
```

`ConsoleApp` recibe las opciones de consola. `ResidenceSystem` valida los casos de uso y conserva `availableSlots`. `OrderedStudentList` es la estructura canonica: sus nodos enlazan objetos `Student`. `ResidenceSystemTest` no participa en la operacion; verifica el sistema y su invariante.

## Estructura y justificacion

Se eligio una **lista enlazada simple ordenada**, implementada manualmente con `head` y `size`. Representa directamente la prioridad y permite insertar o reubicar enlazando nodos, sin ordenamiento global posterior. El invariante es:

```text
(puntaje actual < puntaje siguiente)
o (puntajes iguales y ID actual < ID siguiente)
```

El ID es unico. El desempate por ID ascendente es una decision del proyecto para que el orden sea determinista. No se mantiene `tail`, porque las operaciones requeridas deben recorrer la lista para ubicar la posicion por prioridad o por ID. Tampoco se usan estructuras fuera del alcance actual. La lista favorece una representacion transparente de la prioridad; como contrapartida, la busqueda por ID es `O(n)`, no `O(1)`.

## MVP y flujo de asignacion

Requisitos funcionales clave: registrar aspirantes; consultar y eliminar por ID; modificar el puntaje y actualizar la posicion; definir cupos no negativos; listar aspirantes en prioridad creciente; y listar quienes obtienen o no residencia.

```text
registro / cambio de puntaje / eliminacion
                  |
                  v
  insertar o reinsertar en orden (puntaje, ID)
                  |
                  v
        lista canonica ordenada
             /                 \
primeros min(k,n)          nodos restantes
con residencia             sin residencia
```

Con `k = availableSlots` y `n = size`, admitidos y no admitidos se **derivan** del prefijo de la lista: los primeros `min(k,n)` nodos obtienen residencia y el resto no. No se almacenan colecciones duplicadas; por ello, un cambio de cupos actualiza el resultado sin mover ni copiar estudiantes en estado persistente.

| Operacion | Peor caso |
|---|---:|
| Registrar, consultar por ID, eliminar o modificar puntaje | O(n) |
| Listar ordenados o sin residencia | O(n) |
| Listar con residencia | O(min(k,n)) |
| Establecer cupos; `size` / `isEmpty` | O(1) |

El MVP actual fue validado con 14 escenarios, 133 verificaciones, 14 PASS y 0 FAIL. Las pruebas incluyen lista vacia, inserciones, empates, ID duplicado, eliminacion, reposicionamiento, cupos e entradas invalidas.

**Repositorio:** [[REPO_URL]]

## HUMAN_INPUT_REQUIRED

- Reemplazar `[[NUMERO_EQUIPO]]` por el numero real del equipo.
- Reemplazar `[[INTEGRANTES]]` por los nombres completos.
- Reemplazar `[[REPO_URL]]` por el enlace directo al repositorio compartido.
