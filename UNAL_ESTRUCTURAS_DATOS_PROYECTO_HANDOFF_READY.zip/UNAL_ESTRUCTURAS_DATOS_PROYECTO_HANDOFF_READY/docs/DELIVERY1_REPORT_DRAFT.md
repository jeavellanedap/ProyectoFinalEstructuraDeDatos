# Borrador del reporte técnico - máximo cuatro páginas

## 1. Identificación y problema

**Título provisional:** Sistema priorizado de asignación de Residencias UNAL  
**Integrante:** `[NOMBRE PENDIENTE]`  
**Repositorio:** `[URL PENDIENTE]`

La propuesta seleccionada, Residencias UNAL, atiende una demanda de alojamiento superior a los cupos disponibles. Cada aspirante posee ID único, nombre completo y puntaje socioeconómico; un puntaje menor representa mayor necesidad. El sistema propuesto registra, consulta, modifica y elimina estudiantes, mantiene el orden creciente, asigna cupos desde la mayor prioridad y lista beneficiarios y no beneficiarios (`PROBLEMAS_A_RESOLVER.pdf`, p. 2). La aclaración de Moodle precisa que los cuatro casos del PDF son propuestas, no una selección obligatoria.

El objetivo del MVP es resolver esas operaciones mediante estructuras vistas dentro del alcance actual del curso, con una implementación transparente y complejidades defendibles.

## 2. Requisitos funcionales del MVP

1. Registrar estudiante con ID único, nombre y puntaje.
2. Consultar y eliminar por ID.
3. Modificar el puntaje y actualizar automáticamente la posición.
4. Establecer una cantidad de cupos no negativa.
5. Listar todos por prioridad, con residencia y sin residencia.
6. Mantener prioridad ascendente por puntaje; para empates, ID ascendente como decisión del proyecto.

## 3. Arquitectura y componentes

```mermaid
flowchart TD
    UI[ConsoleApp] --> SYS[ResidenceSystem]
    TEST[ResidenceSystemTest] --> SYS
    SYS --> LIST[OrderedStudentList]
    LIST --> NODE[Node]
    NODE --> STUDENT[Student]
```

- `Student`: datos del aspirante.
- `OrderedStudentList`: estructura manual, nodos y operaciones.
- `ResidenceSystem`: reglas del MVP y cupos.
- `ConsoleApp`: demostración de entrada/salida.
- `ResidenceSystemTest`: pruebas normales, bordes e invariante.

## 4. Estructura elegida e invariante

La estructura canónica es una **ordered singly linked list** con referencia `head` y contador `size`. Está autorizada por Guide capítulos 5-6 y por Arrays and Linked Lists. Para nodos consecutivos se mantiene:

```text
current.score < next.score
OR
(current.score == next.score AND current.id < next.id)
```

La inserción busca primero IDs duplicados y después enlaza el nodo en su posición. Al cambiar puntaje se retira el nodo y se reinserta; no se usa un algoritmo de sorting global. No se guarda `tail` porque ninguna operación requerida mejora su complejidad con él.

Los admitidos y no admitidos no se almacenan como listas adicionales. Con `k = availableSlots`, los primeros `min(k,n)` nodos obtienen residencia y los demás no. Esto elimina estados duplicados y hace que cualquier cambio de cupos se refleje inmediatamente.

```mermaid
flowchart LR
    A[Registrar o modificar] --> B[Buscar ID]
    B --> C[Insertar/reinsertar por score, ID]
    C --> D[Lista canónica ordenada]
    D --> E[Prefijo min k,n: con residencia]
    D --> F[Resto: sin residencia]
```

## 5. Operaciones y complejidad

| Operación | Peor caso | Razón |
|---|---:|---|
| Registrar | O(n) | Búsqueda de ID e inserción son recorridos lineales sucesivos. |
| Consultar por ID | O(n) | No hay índice hash; el ID no es el orden principal. |
| Eliminar | O(n) | Puede recorrerse hasta el último nodo. |
| Modificar puntaje | O(n) | Retirar O(n) y reinsertar O(n) siguen sumando O(n). |
| Listar todos | O(n) | Visita cada nodo. |
| Listar con residencia | O(min(k,n)) | Solo recorre el prefijo beneficiario. |
| Listar sin residencia | O(n) | Omite el prefijo y copia el resto; en total visita hasta n nodos. |
| Establecer cupos | O(1) | Valida y asigna un entero. |
| `size` / `isEmpty` | O(1) | `size` se mantiene con cada modificación. |

Los arrays devueltos por los listados utilizan espacio proporcional al número de estudiantes retornados. No hay costo amortizado relevante en la lista enlazada.

## 6. Flujo general y trade-offs

```mermaid
sequenceDiagram
    actor U as Usuario
    participant C as ConsoleApp
    participant S as ResidenceSystem
    participant L as OrderedStudentList
    U->>C: registrar / consultar / modificar / eliminar
    C->>S: operación validada
    S->>L: recorrido y enlace manual
    L-->>S: resultado con invariante preservado
    S-->>C: estudiantes o estado
    C-->>U: salida de consola
```

La lista enlazada ordenada favorece inserciones y eliminaciones mediante cambios de referencias, y representa directamente la prioridad. Su trade-off es que buscar por ID cuesta `O(n)`. El enunciado pide consultar mediante ID, pero no afirma complejidad constante; introducir hashing mejoraría esa búsqueda, aunque está fuera del alcance académico actual y duplicaría indexación.

No se usan árboles, AVL, heaps, hash, grafos ni algoritmos formales de sorting porque el Guide está limitado a capítulos 1-7 para esta fase. Tampoco se usan colecciones estándar que oculten la estructura evaluada.

## 7. Validación

El harness cubre lista vacía, inserciones en todas las posiciones, empates, ID duplicado, búsquedas inexistentes, eliminación de head/medio/final, reposicionamiento en ambas direcciones, cero/menos/igual/más cupos, partición admitidos/no admitidos, secuencias mixtas e inputs inválidos. Resultado actual: **14 escenarios PASS, 0 FAIL y 133 verificaciones**.

## Pendientes antes del PDF

Completar nombre del único integrante, número de equipo y URL; seleccionar los diagramas que caben en cuatro páginas; sustituir placeholders y exportar el PDF final con enlace al repositorio al final. La fecha límite ya está confirmada: `2026-10-04 23:59`, hora local de Moodle.
