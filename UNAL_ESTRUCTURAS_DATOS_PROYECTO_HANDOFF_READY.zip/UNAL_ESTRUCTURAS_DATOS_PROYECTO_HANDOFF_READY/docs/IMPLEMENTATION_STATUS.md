# Estado de implementación

Fecha de validación: 2026-10-04

`IMPLEMENTATION_PHASE_RESULT = PASS`

## Baseline implementado

| Elemento | Estado | Evidencia |
|---|---|---|
| Problema Residencias UNAL | CONFIRMED | Decisión humana y `PROBLEMAS_A_RESOLVER.pdf`, p. 2 |
| Lenguaje Java | CONFIRMED | Decisión humana; especificación p. 3 permite cualquier lenguaje |
| Ordered singly linked list manual | IMPLEMENTED | `src/OrderedStudentList.java` |
| Orden `(score, ID)` | IMPLEMENTED_AND_TESTED | T-02, T-03, T-04, T-08, T-09, T-10, T-13 |
| IDs únicos | IMPLEMENTED_AND_TESTED | T-05 |
| Búsqueda/eliminación/update | IMPLEMENTED_AND_TESTED | T-06, T-07, T-08, T-09, T-10 |
| Cupos y partición derivada | IMPLEMENTED_AND_TESTED | T-11, T-12 |
| Consola mínima | IMPLEMENTED_AND_EXECUTED | Inicio y salida opción `0` verificados |
| Documentación de Entrega 1 | DRAFT_READY | `DELIVERY1_REPORT_DRAFT.md` |

## Build y pruebas

El `java` originalmente disponible en `PATH` es Oracle JRE `1.8.0_51`; no incluía `javac`. Para validar sin añadir binarios al repositorio se usó temporalmente Temurin OpenJDK/Javac `1.8.0_504`.

```text
openjdk version "1.8.0_504"
javac 1.8.0_504
```

Compilación:

```powershell
javac -Xlint:all -d out src\Student.java src\OrderedStudentList.java src\ResidenceSystem.java src\ConsoleApp.java test\ResidenceSystemTest.java
```

Resultado: exit code 0, sin advertencias de `-Xlint:all`.

Pruebas:

```powershell
java -cp out ResidenceSystemTest
```

Resultado: 14 escenarios, 14 PASS, 0 FAIL, 133 verificaciones.

Consola:

```powershell
java -cp out ConsoleApp
```

Resultado: menú mostrado y salida limpia mediante la opción `0`.

## Estado académico

La aclaración oficial posterior de Moodle establece que, para Entrega 1, el único requisito del prototipo de software es el `README.md`. Este baseline de código, consola y pruebas es trabajo adicional válido y documentado; no es requisito ni bloqueo de la entrega.

- Solo arrays, referencias, nodos y ordered singly linked list.
- Sin colecciones que oculten la estructura.
- Sin sorting posterior.
- Sin árboles, heaps, hashing, grafos, streams, lambdas o frameworks.
- `Scanner`, `Integer` y `System` están respaldados en `references/JAVA_OFFICIAL_REFERENCES.md`.

## Pendientes humanos

- nombres de integrantes;
- número de equipo;
- URL del repositorio;
- revisión, diagramación y exportación del reporte PDF final.
