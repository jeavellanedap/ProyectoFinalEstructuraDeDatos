# Inicio para Codex

Lee primero `../PROJECT_RULES.md`, luego `MOODLE_CLARIFICATION.md`, `DECISIONS.md`, `SOURCE_SCOPE.md` y `REQUIREMENTS_TRACEABILITY.md`. Después consulta directamente los seis PDFs de `../sources/`; los Markdown no sustituyen esta evidencia primaria. La aclaración oficial posterior de Moodle prevalece ante conflictos de interpretación sobre Entrega 1.

Estado: `PROJECT_PROBLEM_DECISION = RESIDENCIAS_UNAL` y `LANGUAGE_DECISION = JAVA` fueron confirmados explícitamente el 2026-10-04. SOURCE_AUDIT e IMPLEMENTATION_PHASE están en PASS. El MVP usa una ordered singly linked list manual; cualquier evolución debe conservar trazabilidad, pruebas e invariante.

Al proponer un cambio, indicar: requisito afectado, estructura/operación, complejidad, fuente del curso y prueba requerida. Mantener `../sources/GUIDE_TO_DATA_STRUCTURES.pdf` estrictamente en capítulos 1–7; los capítulos 8+ no se usan para código ni decisiones actuales. No introducir librerías que reemplacen la estructura evaluada, sorting posterior, estructuras posteriores ni GUI.

Diseño confirmado: singly linked list ordenada por `(puntaje socioeconómico, ID)` y asignación derivada de `availableSlots`, no listas sincronizadas de admitidos/rechazados. Buscar por ID es O(n). Este código es trabajo adicional opcional: para Entrega 1 el prototipo requerido es únicamente `README.md`; no se exigen commits mínimos. No iniciar diseño de E2/E3, pues Moodle indica que serán implementaciones diferentes.
