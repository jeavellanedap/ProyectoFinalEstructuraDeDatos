# Trazabilidad de requisitos - Residencias UNAL

Fuente funcional seleccionada: `../sources/PROBLEMAS_A_RESOLVER.pdf`, p. 2. La aclaración oficial de Moodle del 2026-10-04 establece que los cuatro casos del PDF son ideas/propuestas, no una selección obligatoria. Por tanto, las filas R-01 a R-11 describen el alcance elegido por el equipo para `RESIDENCIAS_UNAL`, no requisitos universales de Entrega 1 ni una imposición docente. Problema y lenguaje fueron confirmados por decisión humana el 2026-10-04.

| ID | Requirement | Clasificación | Design decision | Clase / método previsto | Operación de estructura | Complejidad prevista | Prueba(s) | Estado |
|---|---|---|---|---|---|---:|---|---|
| R-01 | Registrar ID, nombre completo y puntaje socioeconómico | SELECTED_PROJECT_SCOPE | `int` para ID/puntaje; nombre no vacío | `ResidenceSystem.registerStudent` | búsqueda de duplicado + inserción ordenada | O(n) | T-02, T-03, T-04 | IMPLEMENTED_AND_TESTED |
| R-02 | ID único | SELECTED_PROJECT_SCOPE | Rechazar registro duplicado sin modificar estado | `registerStudent` | `findById` | O(n) | T-05 | IMPLEMENTED_AND_TESTED |
| R-03 | Indicar cupos disponibles | SELECTED_PROJECT_SCOPE | `availableSlots >= 0` | `setAvailableSlots` | asignación de campo | O(1) | T-11, T-12, T-14 | IMPLEMENTED_AND_TESTED |
| R-04 | Consultar estudiante mediante ID | SELECTED_PROJECT_SCOPE | No interpretar “directo” como O(1) | `findStudentById` | recorrido desde `head` | O(n) | T-01, T-06 | IMPLEMENTED_AND_TESTED |
| R-05 | Listar por puntaje creciente | SELECTED_PROJECT_SCOPE | Desempate por ID ascendente | `getStudentsOrdered` | recorrido completo | O(n) | T-02, T-03, T-04, T-10 | IMPLEMENTED_AND_TESTED |
| R-06 | Asignar cupos empezando por menor puntaje | SELECTED_PROJECT_SCOPE | Primeros `min(k,n)` de la lista | `getAcceptedStudents` | recorrido de prefijo | O(min(k,n)) | T-11, T-12 | IMPLEMENTED_AND_TESTED |
| R-07 | Listar quienes obtienen residencia | SELECTED_PROJECT_SCOPE | Resultado derivado; sin lista persistente | `getAcceptedStudents` | recorrido de prefijo | O(min(k,n)) | T-11, T-12 | IMPLEMENTED_AND_TESTED |
| R-08 | Listar quienes no obtienen residencia | SELECTED_PROJECT_SCOPE | Resultado derivado; omitir prefijo y copiar resto | `getRejectedStudents` | recorrido completo en peor caso | O(n) | T-11, T-12 | IMPLEMENTED_AND_TESTED |
| R-09 | Modificar puntaje y actualizar posición | SELECTED_PROJECT_SCOPE | Retirar, actualizar y reinsertar; sin sorting | `updateStudentScore` | búsqueda/eliminación + inserción ordenada | O(n) | T-01, T-08, T-09, T-10 | IMPLEMENTED_AND_TESTED |
| R-10 | Eliminar estudiantes | SELECTED_PROJECT_SCOPE | Eliminar por ID | `removeStudent` | recorrido + desenlace | O(n) | T-01, T-07 | IMPLEMENTED_AND_TESTED |
| R-11 | Menor puntaje implica mayor prioridad | SELECTED_PROJECT_SCOPE | Invariante `(score, ID)` | `comesBefore`, inserción | comparación constante durante recorrido | O(n) por inserción | T-02, T-03, T-04, T-10 | IMPLEMENTED_AND_TESTED |
| D-01 | Empates de puntaje | PROJECT_DESIGN_DECISION | ID ascendente | `comesBefore` | comparación | O(1) por comparación | T-04, T-09 | IMPLEMENTED_AND_TESTED |
| D-02 | Lista vacía, `size` e invariante | PROJECT_DESIGN_DECISION | `head == null`, `size == 0` | `isEmpty`, `size`, `hasValidInvariant` | acceso / recorrido de auditoría | O(1) / O(n) | T-01, T-13 | IMPLEMENTED_AND_TESTED |

Validación ejecutada: 14 escenarios, 14 PASS, 0 FAIL y 133 verificaciones. Las complejidades se auditaron contra los recorridos reales de `OrderedStudentList` y `ResidenceSystem`. Esta implementación y sus pruebas son trabajo adicional opcional para Entrega 1; el `README.md` es el único requisito del prototipo de software según Moodle.
