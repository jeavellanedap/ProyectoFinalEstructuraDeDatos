# Alcance de fuentes

Orden de prioridad: aclaración oficial posterior de Moodle documentada en `MOODLE_CLARIFICATION.md` (para conflictos de interpretación de Entrega 1) → PDFs primarios locales en `../sources/` → documentación oficial del lenguaje cuando este se confirme. Los documentos Markdown del repositorio orientan el trabajo, pero no sustituyen las fuentes oficiales.

| Fuente | Uso autorizado en este workspace |
|---|---|
| `../sources/ESPECIFICACION_ENTREGA1_PROYECTO.pdf` | Entregables, límites y fases del proyecto. |
| Aclaración oficial de Moodle, 2026-10-04 | Evidencia posterior y más específica: deadline, README como único requisito del prototipo, archivos/código opcionales, commits no evaluados, propuestas no obligatorias y E2/E3 diferentes. Prevalece ante conflicto interpretativo. |
| `../sources/PROBLEMAS_A_RESOLVER.pdf` | Cuatro ideas/propuestas. Si el equipo selecciona una, orienta su alcance funcional; no obliga a seleccionar ni resolver uno de esos casos. |
| `../sources/GUIDE_TO_DATA_STRUCTURES.pdf`, caps. 1–7 únicamente | Big-O, interfaces/ADT, arrays, listas, nodos/referencias, listas enlazadas, listas ordenadas, stacks y queues. **Límite estricto: capítulos 8+ fuera de alcance para código y decisiones actuales.** |
| `../sources/ARRAYS_AND_LINKED_LISTS_RHODES.pdf` | Arrays, listas singly/doubly y complejidades de operaciones. |
| `../sources/STACKS_AND_QUEUES_RHODES.pdf` | ADT y representaciones permitidas de stack/queue. |
| `../sources/DYNAMIC_ARRAYS_AMORTIZED_ANALYSIS_RHODES.pdf` | `size`, `capacity`, redimensionamiento y análisis amortizado. |
| Documentación oficial del lenguaje | Sintaxis y comportamiento de APIs que no reemplacen la estructura evaluada. |

Los PDFs están disponibles localmente para auditoría, pero se excluyen de Git mediante `/.gitignore`. Véanse el mapeo de nombres y las restricciones en `references/SOURCES_INDEX.md` y `../sources/README.md`.
