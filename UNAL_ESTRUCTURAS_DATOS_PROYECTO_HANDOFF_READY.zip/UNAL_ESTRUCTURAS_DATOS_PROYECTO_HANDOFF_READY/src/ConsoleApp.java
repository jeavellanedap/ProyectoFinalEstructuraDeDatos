import java.util.Scanner;

/** Minimal console demonstration; the data structure remains the project focus. */
public final class ConsoleApp {
    private ConsoleApp() {
    }

    public static void main(String[] args) {
        ResidenceSystem system = new ResidenceSystem();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        System.out.println("Residencias UNAL - MVP");
        while (running) {
            printMenu();
            int option = readInt(scanner, "Opcion: ");

            switch (option) {
                case 1:
                    registerStudent(scanner, system);
                    break;
                case 2:
                    findStudent(scanner, system);
                    break;
                case 3:
                    printStudents("Estudiantes ordenados", system.getStudentsOrdered());
                    break;
                case 4:
                    updateScore(scanner, system);
                    break;
                case 5:
                    removeStudent(scanner, system);
                    break;
                case 6:
                    setAvailableSlots(scanner, system);
                    break;
                case 7:
                    printStudents("Con residencia", system.getAcceptedStudents());
                    break;
                case 8:
                    printStudents("Sin residencia", system.getRejectedStudents());
                    break;
                case 0:
                    running = false;
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        }
        System.out.println("Fin.");
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("1. Registrar estudiante");
        System.out.println("2. Consultar por ID");
        System.out.println("3. Listar estudiantes");
        System.out.println("4. Modificar puntaje");
        System.out.println("5. Eliminar estudiante");
        System.out.println("6. Establecer cupos");
        System.out.println("7. Mostrar estudiantes con residencia");
        System.out.println("8. Mostrar estudiantes sin residencia");
        System.out.println("0. Salir");
    }

    private static void registerStudent(Scanner scanner, ResidenceSystem system) {
        int id = readInt(scanner, "ID: ");
        System.out.print("Nombre completo: ");
        String fullName = scanner.nextLine();
        int score = readInt(scanner, "Puntaje socioeconomico: ");
        try {
            boolean registered = system.registerStudent(id, fullName, score);
            System.out.println(registered ? "Estudiante registrado." : "El ID ya existe.");
        } catch (IllegalArgumentException error) {
            System.out.println("Dato invalido: " + error.getMessage());
        }
    }

    private static void findStudent(Scanner scanner, ResidenceSystem system) {
        int id = readInt(scanner, "ID: ");
        Student student = system.findStudentById(id);
        System.out.println(student == null ? "Estudiante no encontrado." : student);
    }

    private static void updateScore(Scanner scanner, ResidenceSystem system) {
        int id = readInt(scanner, "ID: ");
        int score = readInt(scanner, "Nuevo puntaje: ");
        boolean updated = system.updateStudentScore(id, score);
        System.out.println(updated ? "Puntaje actualizado." : "Estudiante no encontrado.");
    }

    private static void removeStudent(Scanner scanner, ResidenceSystem system) {
        int id = readInt(scanner, "ID: ");
        boolean removed = system.removeStudent(id);
        System.out.println(removed ? "Estudiante eliminado." : "Estudiante no encontrado.");
    }

    private static void setAvailableSlots(Scanner scanner, ResidenceSystem system) {
        int slots = readInt(scanner, "Cupos disponibles: ");
        try {
            system.setAvailableSlots(slots);
            System.out.println("Cupos actualizados.");
        } catch (IllegalArgumentException error) {
            System.out.println("Dato invalido: " + error.getMessage());
        }
    }

    private static void printStudents(String title, Student[] students) {
        System.out.println(title + " (" + students.length + "):");
        if (students.length == 0) {
            System.out.println("  Sin estudiantes.");
            return;
        }
        for (int i = 0; i < students.length; i++) {
            System.out.println("  " + students[i]);
        }
    }

    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException error) {
                System.out.println("Ingrese un numero entero valido.");
            }
        }
    }
}
