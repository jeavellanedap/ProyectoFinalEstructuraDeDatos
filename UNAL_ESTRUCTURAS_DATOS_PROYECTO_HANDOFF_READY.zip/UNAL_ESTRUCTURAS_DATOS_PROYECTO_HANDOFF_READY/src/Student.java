/**
 * Student registered in the Residencias UNAL system.
 * Requirement: PROBLEMAS_A_RESOLVER.pdf, p. 2.
 */
public final class Student {
    private final int id;
    private final String fullName;
    private int socioeconomicScore;

    public Student(int id, String fullName, int socioeconomicScore) {
        this.id = id;
        this.fullName = fullName;
        this.socioeconomicScore = socioeconomicScore;
    }

    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public int getSocioeconomicScore() {
        return socioeconomicScore;
    }

    /** Package-private: only the data-structure/domain implementation may reorder it. */
    void setSocioeconomicScore(int socioeconomicScore) {
        this.socioeconomicScore = socioeconomicScore;
    }

    @Override
    public String toString() {
        return "Student{id=" + id
                + ", fullName='" + fullName + "'"
                + ", socioeconomicScore=" + socioeconomicScore + "}";
    }
}
