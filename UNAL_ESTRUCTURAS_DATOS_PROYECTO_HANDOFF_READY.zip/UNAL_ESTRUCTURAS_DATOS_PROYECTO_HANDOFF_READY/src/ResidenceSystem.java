/**
 * Domain operations for the Residencias UNAL MVP.
 * Accepted/rejected students are derived from one canonical ordered list.
 */
public final class ResidenceSystem {
    private final OrderedStudentList orderedStudents;
    private int availableSlots;

    public ResidenceSystem() {
        orderedStudents = new OrderedStudentList();
        availableSlots = 0;
    }

    /** Worst-case time: O(n). */
    public boolean registerStudent(int id, String fullName, int socioeconomicScore) {
        String validatedName = validateName(fullName);
        return orderedStudents.insert(new Student(id, validatedName, socioeconomicScore));
    }

    /** Worst-case time: O(n). */
    public Student findStudentById(int id) {
        return orderedStudents.findById(id);
    }

    /** Worst-case time: O(n). */
    public boolean removeStudent(int id) {
        return orderedStudents.removeById(id) != null;
    }

    /** Worst-case time: O(n). */
    public boolean updateStudentScore(int id, int newScore) {
        return orderedStudents.updateScoreById(id, newScore);
    }

    /** Time: O(1). */
    public void setAvailableSlots(int availableSlots) {
        if (availableSlots < 0) {
            throw new IllegalArgumentException("Available slots cannot be negative.");
        }
        this.availableSlots = availableSlots;
    }

    public int getAvailableSlots() {
        return availableSlots;
    }

    /** Time: O(n). */
    public Student[] getStudentsOrdered() {
        return orderedStudents.toArray();
    }

    /** Time: O(min(k, n)), where k is availableSlots. */
    public Student[] getAcceptedStudents() {
        return orderedStudents.firstStudents(availableSlots);
    }

    /** Worst-case time: O(n). */
    public Student[] getRejectedStudents() {
        return orderedStudents.studentsAfter(availableSlots);
    }

    public int size() {
        return orderedStudents.size();
    }

    public boolean isEmpty() {
        return orderedStudents.isEmpty();
    }

    public boolean hasValidInvariant() {
        return orderedStudents.hasValidInvariant();
    }

    private String validateName(String fullName) {
        if (fullName == null) {
            throw new IllegalArgumentException("Full name cannot be null.");
        }
        String trimmedName = fullName.trim();
        if (trimmedName.length() == 0) {
            throw new IllegalArgumentException("Full name cannot be empty.");
        }
        return trimmedName;
    }
}
