# Código fuente

- `Student.java`: modelo mínimo del aspirante.
- `OrderedStudentList.java`: ordered singly linked list manual, nodos e invariante `(score, ID)`.
- `ResidenceSystem.java`: operaciones del caso de uso y asignación derivada.
- `ConsoleApp.java`: demostración de consola.

No se usan colecciones estándar para resolver la estructura, sorting posterior, frameworks ni conceptos posteriores al capítulo 7 del Guide.
