/**
 * Manually implemented ordered singly linked list.
 *
 * Invariant: students are ordered by socioeconomic score ascending and then
 * by ID ascending. The size field equals the number of nodes reachable from head.
 */
public final class OrderedStudentList {
    private static final class Node {
        private final Student student;
        private Node next;

        private Node(Student student) {
            this.student = student;
        }
    }

    private Node head;
    private int size;

    public OrderedStudentList() {
        head = null;
        size = 0;
    }

    /**
     * Inserts a student while preserving the order. Returns false for duplicate IDs.
     * Worst-case time: O(n). Extra space: O(1), excluding the new node.
     */
    public boolean insert(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student cannot be null.");
        }
        if (findById(student.getId()) != null) {
            return false;
        }
        insertKnownUnique(student);
        return true;
    }

    /** Worst-case time: O(n). */
    public Student findById(int id) {
        Node current = head;
        while (current != null) {
            if (current.student.getId() == id) {
                return current.student;
            }
            current = current.next;
        }
        return null;
    }

    /** Worst-case time: O(n). Returns the removed student, or null. */
    public Student removeById(int id) {
        Node previous = null;
        Node current = head;

        while (current != null && current.student.getId() != id) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            return null;
        }

        if (previous == null) {
            head = current.next;
        } else {
            previous.next = current.next;
        }
        size--;
        return current.student;
    }

    /**
     * Removes, updates and reinserts the student to preserve the invariant.
     * Worst-case time: O(n), since two sequential linear traversals remain O(n).
     */
    public boolean updateScoreById(int id, int newScore) {
        Student student = removeById(id);
        if (student == null) {
            return false;
        }
        student.setSocioeconomicScore(newScore);
        insertKnownUnique(student);
        return true;
    }

    /** Time: O(n). */
    public Student[] toArray() {
        Student[] result = new Student[size];
        Node current = head;
        int index = 0;
        while (current != null) {
            result[index] = current.student;
            index++;
            current = current.next;
        }
        return result;
    }

    /** Time: O(min(limit, n)). */
    public Student[] firstStudents(int limit) {
        if (limit < 0) {
            throw new IllegalArgumentException("Limit cannot be negative.");
        }
        int resultSize = limit < size ? limit : size;
        Student[] result = new Student[resultSize];
        Node current = head;
        int index = 0;
        while (index < resultSize) {
            result[index] = current.student;
            index++;
            current = current.next;
        }
        return result;
    }

    /** Worst-case time: O(n). */
    public Student[] studentsAfter(int skippedStudents) {
        if (skippedStudents < 0) {
            throw new IllegalArgumentException("Skipped students cannot be negative.");
        }
        int skipped = skippedStudents < size ? skippedStudents : size;
        Student[] result = new Student[size - skipped];
        Node current = head;
        int index = 0;

        while (index < skipped) {
            current = current.next;
            index++;
        }

        index = 0;
        while (current != null) {
            result[index] = current.student;
            index++;
            current = current.next;
        }
        return result;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Test/audit helper. Checks ordering and the stored size in O(n).
     * ID uniqueness is enforced by insert and independently tested.
     */
    public boolean hasValidInvariant() {
        int countedNodes = 0;
        Node current = head;
        while (current != null) {
            countedNodes++;
            if (current.next != null
                    && !comesBefore(current.student, current.next.student)) {
                return false;
            }
            current = current.next;
        }
        return countedNodes == size;
    }

    private void insertKnownUnique(Student student) {
        Node newNode = new Node(student);

        if (head == null || comesBefore(student, head.student)) {
            newNode.next = head;
            head = newNode;
            size++;
            return;
        }

        Node current = head;
        while (current.next != null
                && comesBefore(current.next.student, student)) {
            current = current.next;
        }

        newNode.next = current.next;
        current.next = newNode;
        size++;
    }

    private boolean comesBefore(Student first, Student second) {
        if (first.getSocioeconomicScore() < second.getSocioeconomicScore()) {
            return true;
        }
        return first.getSocioeconomicScore() == second.getSocioeconomicScore()
                && first.getId() < second.getId();
    }
}
